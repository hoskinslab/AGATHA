%% function
function[final_decision]= shorteventcount_Frame(green, L_f,S_f,b)
%%
%function[final_decision]= shorteventcount_Frame(green, L_f,S_f,b_time)
%
% first file is assighned as green by default

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function classifies and counts the long and short binding events based
% on the user input
% Input:
%green: contains all the information from Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers).
%b_time: the corresponding time information from cell traces array
%L_f: Lower  delta frame limit. Any event with the delta frame  value greater
%than L_t will be counted as long event
%S_f: upper delta frame limit. Any event with the delta frame value
%smaller than S_f will be counted as short event



%output
%final_decision
%(Total number of short events)(Total number of long events)( number the short events before a long event) (Long events delta frame)
%Note: depending upon  data user can change the conditions to classify
%events

%11/16/2017  Fatemehsadat Jamalidinan  created
%11/17/2017  Fatemehsadat Jamalidinan and Harpreet Kaur  updated for comments

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
long_frame=L_f;    
short_frame=S_f;    


num_long=0;
num_short=0;
long=[];
short=[];
for i=1:size(green,1)
    if(green(i,4)>=long_frame)
        
       
        num_long=num_long+1;
        long=[long;i];
    elseif((green(i,4)<=short_frame))
    num_short=num_short+1;
    short=[short;i];
    end
end
counter=zeros(length(long),1);
point=zeros(length(short),1);
for i=1:length(long)
    if(i==3)
        tt=0;
    end
    for j=1:length(short)
        if(green(long(i),2)>green(short(j),3))
            if(point(j)==0)
            point(j)=1;
            counter(i)=counter(i)+1;
            end
        end
    end
end
            
            
        
        
    






final_decision{1,1}= num_long;
final_decision{2,1}= num_short;
final_decision{3,1}= counter;
final_decision{4,1}= green(long,4);
