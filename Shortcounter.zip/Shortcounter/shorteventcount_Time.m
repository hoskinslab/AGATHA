%% function
function[final_decision]= shorteventcount_Time(green, L_t,S_t,b_time)
%%
%function[final_decision]= shorteventcount_Time(green, L_t,S_t,b_time)
%
% first file is assighned as green by default

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function classifies and counts the long and short binding events based
% on the user input
% Input:
%green: contains all the information from Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers).
%b_time: the corresponding time information from cell traces array
%L_t: Lower time interval limit. Any event with the time interval value greater
%than L_t will be counted as long event
%S_t: upper time interval limit. Any event with the time interval value
%smaller than S_t will be counted as short event



%output
%final_decision
%(Total number of short events)(Total number of long events)( number the short events before a long event) (Long events delta time)


%Note: depending upon  data user can change the conditions to classify
%events

%11/16/2017  Fatemehsadat Jamalidinan  created
%11/17/2017  Fatemehsadat Jamalidinan and Harpreet Kaur  updated for comments

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

new_aoig = cat(1, b_time{1,1}{:,2}); %find out aoi numbers of green,b_time{1,1} is  All Traces cell array from green Interval file
b_time_green=find(new_aoig==green(1,7)); %find out aoi number of green
green_time=b_time{1,1}{b_time_green,9};%find corresponding times


long_event=L_t;
short_event=S_t;


num_long=0;
num_short=0;
long=[];
short=[];
for i=1:size(green,1)
    if(green(i,5)>=long_event)
        
        
        num_long=num_long+1;
        long=[long;i];
    elseif((green(i,5)<=short_event))
        num_short=num_short+1;
        short=[short;i];
    end
end
counter=zeros(length(long),1);
point=zeros(length(short),1);
for i=1:length(long)
    if(i==3)
        tt=0;
    end
    for j=1:length(short)
        if(green_time(green(long(i),2))>green_time(green(short(j),3)))
            if(point(j)==0)
                point(j)=1;
                counter(i)=counter(i)+1;
            end
        end
    end
end











final_decision{1,1}= num_long;
final_decision{2,1}= num_short;
final_decision{3,1}= counter;
final_decision{4,1}= green(long,5);
