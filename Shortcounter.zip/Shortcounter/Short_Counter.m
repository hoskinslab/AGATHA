function varargout = Short_Counter(varargin)
%2017  Fatemehsadat Jamalidinan  created
%SHORT_COUNTER MATLAB code file for Short_Counter.fig
%      SHORT_COUNTER, by itself, creates a new SHORT_COUNTER or raises the existing
%      singleton*.
%
%      H = SHORT_COUNTER returns the handle to a new SHORT_COUNTER or the handle to
%      the existing singleton*.
%
%      SHORT_COUNTER('Property','Value',...) creates a new SHORT_COUNTER using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to Short_Counter_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      SHORT_COUNTER('CALLBACK') and SHORT_COUNTER('CALLBACK',hObject,...) call the
%      local function named CALLBACK in SHORT_COUNTER.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Short_Counter

% Last Modified by GUIDE v2.5 29-Nov-2017 12:39:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Short_Counter_OpeningFcn, ...
                   'gui_OutputFcn',  @Short_Counter_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end
try
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
catch
    error=1;
end
% End initialization code - DO NOT EDIT


% --- Executes just before Short_Counter is made visible.
function Short_Counter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)
imshow('bg_header.png')
% Choose default command line output for Short_Counter
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
   set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
  set(handles.deltatime, 'enable','off')
  set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')


set(handles.Time, 'Value',0)
set(handles.Frame, 'Value',0)
set(handles.MThree, 'Value',0)
set(handles.One, 'Value',0)
set(handles.three, 'Value',0)

set(handles.deltaframe,'String','')
set(handles.framelimit,'String','')
set(handles.deltatime,'String','')
set(handles.timelimit,'String','')
set(handles.Green_dir,'String','');
set(handles.Out_dir,'String','');

% UIWAIT makes Short_Counter wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Short_Counter_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Time.
function Time_Callback(hObject, eventdata, handles)
% hObject    handle to Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.Time, 'Value')==1)
set(handles.timelimit, 'enable','on')
  set(handles.text3, 'enable','on')
  set(handles.text5, 'enable','on')
  set(handles.deltatime, 'enable','on')
else
    set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
  set(handles.deltatime, 'enable','off')
end

if(get(handles.Frame, 'Value')==0)
  set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')
else
      set(handles.framelimit, 'enable','on')
  set(handles.text2, 'enable','on')
  set(handles.text6, 'enable','on')
set(handles.deltaframe, 'enable','on')
end
    
% Hint: get(hObject,'Value') returns toggle state of Time


% --- Executes on button press in three.
function three_Callback(hObject, eventdata, handles)
% hObject    handle to three (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of three


% --- Executes on button press in Input_green.
function Input_green_Callback(hObject, eventdata, handles)
% hObject    handle to Input_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green  OUTPUT_DIR;

% hObject    handle to In_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
[fn, fp]=uigetfile('*.mat', 'Select the 1st Interval .mat File to Analyze', 'Multiselect', 'off');
% fp_baseout = uigetdir(fp, 'Select a folder to write images and step counts to:');


%If only one file selected, MATLAB returns character vector.
%If more than one, MATLAB returns cell array of character vectors...
%Need to put it into a cell array for the downstream analysis.

eval(['load ' [fp fn] ' -mat']);
a_green=Intervals.CumulativeIntervalArray;
b_green=Intervals.AllTracesCellArray;
set(handles.Out_dir,'String','');
set(handles.Green_dir,'String',[fp fn]);
catch
   msgbox('The machine can not read the interval .mat file you wish to analyze');
    error=1;
    set(handles.Green_dir,'String','');
end

function framelimit_Callback(hObject, eventdata, handles)
% hObject    handle to framelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of framelimit as text
%        str2double(get(hObject,'String')) returns contents of framelimit as a double


% --- Executes during object creation, after setting all properties.
function framelimit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to framelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in analyze.
function analyze_Callback(hObject, eventdata, handles)
% hObject    handle to analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green  OUTPUT_DIR;
set(handles.busy,'String','busy')
one_pointer=0;
mtherr_pointer=0;
three_pointer=0;
if(get(handles.MThree, 'Value')==1)
mtherr_pointer=1;
end
if(get(handles.One, 'Value')==1)
one_pointer=1;
end
if(get(handles.three, 'Value')==1)
three_pointer=1;
end
if((three_pointer||one_pointer||mtherr_pointer)==0)
    msgbox('Select at least one type of event(-3,1,3)')
end
a{:,1}=a_green;
b{:,1}=b_green;
AOI_max=0;
AOI_max=max(max(AOI_max,a{:,1}(:,7)));

for i=1:AOI_max
    for k=1:1
        f{i,k}=find(a{:,k}(:,7)==i);
    end
end
cvb=[];

j=1;

for i=1:AOI_max
    tt=1;
    for k=1:1
        if(isempty(f{i,k}))
            tt=0;
        end
        
    end
    if(tt==1)
        cvb=[cvb; i];
    end
end
for i=1:length(cvb)
    out{i,1}=a{1,1}([f{cvb(i),1}]',:);

end
clear cvb f g k j i Intervals tt AOI_max a
eventlen=[];
%% finding the high values base the user request
if(one_pointer && mtherr_pointer && three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==1));(find(out{i,1}(:,1)==3))];
   
    out1{i1,1}=out{i,1}((vb),:);
    tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(one_pointer && mtherr_pointer) 
   i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==1))];
    
    out1{i1,1}=out{i,1}((vb),:);
    tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end   
elseif(one_pointer && three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==1));(find(out{i,1}(:,1)==3))];
  
    out1{i1,1}=out{i,1}((vb),:);
   tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(mtherr_pointer && three_pointer)
    i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==3))];

    out1{i1,1}=out{i,1}((vb),:);
   tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(mtherr_pointer)
  i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3))];
   
    out1{i1,1}=out{i,1}((vb),:);
    tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end

elseif(one_pointer )
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==1))];
 
    out1{i1,1}=out{i,1}((vb),:);
   tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end

elseif(three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==3))];
    out1{i1,1}=out{i,1}((vb),:);
   tempa=[out1{i1,1}((1:(end-1)),5),out1{i1,1}((2:(end)),5)];
    eventlen=[eventlen;tempa];
  if(size(out1{i1,1},1)==0 )
        i1=i1-1;
    end
    i1=i1+1;
end

end

if( (length(out1{1,1}))==0)
    msgbox('The machine couldnot find the matching event')
end
X=eventlen(:,1);
Y=eventlen(:,2);
h=figure;
plot(X,Y,'ro');

ylabel('\Delta t_{m+1}')
xlabel('\Delta t_m')
title('Correlation Graph')
saveas(h,[OUTPUT_DIR '/out.fig']);

if(get(handles.Time, 'Value')==1)
 L_f=str2num(get(handles.timelimit,'String'));
 S_f=str2num(get(handles.deltatime,'String'));
    



 ii=1;
 for i=1:size(out1,1)
     if(i==2)
         kl=0;
     end
     
     [outt]=shorteventcount_Time(out1{i,1}, L_f,S_f,b);
     
     final{i}=outt;
     
     if(ii==7)
         kj=0;
     end
    
     
     for tt=1:size(outt{3},1)
         Counter(i,1)=out1{i,1}(1,7);
         Counter(i,2)=outt{1};
         Counter(i,3)=outt{2};
         Short_Counter(ii,1)=out1{i,1}(1,7);
         
         Short_Counter(ii,2)=outt{3}(tt);
         Short_Counter(ii,3)=outt{4}(tt);
      
          ii=ii+1;
     end
     
    
 end
Long_Short_counts.Description=('((AOI)(Total number of short events)(Total number of long events)'); 
Long_Short_counts.out=Counter;
save([OUTPUT_DIR '/Long_Short_counts_Time.mat'],'Long_Short_counts');
Short_counter.Description=('((AOI)( Total number of the short events before a long event) (Long events length)'); 
Short_counter.out=Short_Counter;
save([OUTPUT_DIR '/Short_counter_Time.mat'],'Short_counter');
end

if(get(handles.Frame, 'Value')==1)

 L_f=str2num(get(handles.framelimit,'String'));
 S_f=str2num(get(handles.deltaframe,'String'));

 ii=1;
 for i=1:size(out1,1)
     if(i==2)
         kl=0;
     end
     
     [outt]=shorteventcount_Frame(out1{i,1}, L_f,S_f,b);
     
     final{i}=outt;
     
     if(ii==7)
         kj=0;
     end
    
     
     for tt=1:size(outt{3},1)
         Counter(i,1)=out1{i,1}(1,7);
         Counter(i,2)=outt{1};
         Counter(i,3)=outt{2};
         Short_Counter(ii,1)=out1{i,1}(1,7);
         
         Short_Counter(ii,2)=outt{3}(tt);
         Short_Counter(ii,3)=outt{4}(tt);
      
          ii=ii+1;
     end
     
    
 end
Long_Short_counts.Description=('((AOI)(Total number of short events)(Total number of long events)'); 
Long_Short_counts.out=Counter;
save([OUTPUT_DIR '/Long_Short_counts_Frame.mat'],'Long_Short_counts');
Short_counter.Description=('((AOI)( Total number of the short events before a long event) (Long events length)'); 
Short_counter.out=Short_Counter;
save([OUTPUT_DIR '/Short_counter_Frame.mat'],'Short_counter');
end
set(handles.busy,'String','')
% --- Executes on button press in Frame.
function Frame_Callback(hObject, eventdata, handles)
% hObject    handle to Frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.Frame, 'Value')==1)
  set(handles.framelimit, 'enable','on')
  set(handles.text2, 'enable','on')
  set(handles.text6, 'enable','on')
set(handles.deltaframe, 'enable','on')
else
    set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')
end

if(get(handles.Time, 'Value')==0)
set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
set(handles.deltatime, 'enable','off')
else
    set(handles.timelimit, 'enable','on')
  set(handles.text3, 'enable','on')
  set(handles.text5, 'enable','on')
set(handles.deltatime, 'enable','on')
end
% Hint: get(hObject,'Value') returns toggle state of Frame



function timelimit_Callback(hObject, eventdata, handles)
% hObject    handle to timelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timelimit as text
%        str2double(get(hObject,'String')) returns contents of timelimit as a double


% --- Executes during object creation, after setting all properties.
function timelimit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function deltatime_Callback(hObject, eventdata, handles)
% hObject    handle to deltatime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of deltatime as text
%        str2double(get(hObject,'String')) returns contents of deltatime as a double


% --- Executes during object creation, after setting all properties.
function deltatime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deltatime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in output.
function output_Callback(hObject, eventdata, handles)
% hObject    handle to output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green  OUTPUT_DIR;

 OUTPUT_DIR = uigetdir('Select a folder to write images and results to:');

   set(handles.Out_dir,'String',OUTPUT_DIR); 
    if(OUTPUT_DIR==0)
        set(handles.Out_dir,'String',''); 
    end

  






function Green_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Green_dir as text
%        str2double(get(hObject,'String')) returns contents of Green_dir as a double


% --- Executes during object creation, after setting all properties.
function Green_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Out_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Out_dir as text
%        str2double(get(hObject,'String')) returns contents of Out_dir as a double


% --- Executes during object creation, after setting all properties.
function Out_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function deltaframe_Callback(hObject, eventdata, handles)
% hObject    handle to deltaframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of deltaframe as text
%        str2double(get(hObject,'String')) returns contents of deltaframe as a double


% --- Executes during object creation, after setting all properties.
function deltaframe_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deltaframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in MThree.
function MThree_Callback(hObject, eventdata, handles)
% hObject    handle to MThree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MThree


% --- Executes on button press in One.
function One_Callback(hObject, eventdata, handles)
% hObject    handle to One (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of One


% --- Executes on button press in usermanual.
function usermanual_Callback(hObject, eventdata, handles)
% hObject    handle to usermanual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    winopen('ShortCounter.pdf');
catch
    system('open ShortCounter.pdf');
end
