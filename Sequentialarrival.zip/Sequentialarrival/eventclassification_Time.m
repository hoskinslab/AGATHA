%% function
function[final_decision,numberA,numberB,numberAB,numbers,numberme,numbern,time_stvsrl,event, final_Frame,final_Time,iout,A1,B1,S1,M1,N1]= eventclassification_Time(green,red,b_time,userinput,delta_t)
%%
%function[final_decision,numberA,numberB,numberAB,numbers,numberme,numbern,time_stvsrl,event, final_Frame,final_Time,iout,A1,B1,S1,M1,N1]= eventclassification_Time(green,red,b_time,userinput,delta_t)
%
% first file is assighned as green by default
% Second file is assighned as red by default
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function classifies two color colocalization events based on
% sequential arrival and departure times vs the  sequential arrival times and
% variation in the departure times
% Input:
%green: contains all the information from Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers) for first color.
%red:contains all the information from  Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers) for the second color.
%b_time: the corresponding time information from cell traces array
%userinput:% if the  difference between the time corresponding to the start frames of two colors intervals is higher than this value we take it as a 'F' event
%delta_t:Decision parameter for the classification of stype event where both color events appeared and depart simultaneouly but for the short period.delta_t is the upper time limit corresponding to the arrival time differences 
%to decide if the arrival of the two events is simultaneous or not.

%output
%final_decision:Output information will be saved in this structure such as
%Frame:(events types(A, B, C, S, M, N))(relative start frame)(Frame_overlap)(relative release frame)(#AoI)(delta Frame_color one)(delta Frame_color2)(start frame_second color-end frame_first color)
%Time:(events types(A, B, C, S, M, N))(relative start time)(overlap time)(relative release time)(#AoI)(delta Time_color one)(delta time_color2)( time corresponding the start frame of the second color-time corresponding the  end frame of the first color)
%A type: 2nd color event occurs after the 1st color event and 2nd color
%departs after the first is lost
%B type: 2nd color event occurs after the 1st color event and 2nd color
%departs before the first is lost.
%C type: combination of both A and B type of events. Where B type occurs
%once or several times before the A type
%S type: both color events appeared and depart simultaneouly but for the short period of time described as Stochastic
%M type: if the 2nd color events occurs after the first color event is
%over.
%N type: if the 2nd color events occurs before the first color event has
%started
%F type: Events are flagged if the 2nd color event occurs a long time
%after the first color event is lost or 2nd color starts very early before the first
%color event has started
%numberA:number of the events classified as A
%numberB:number of the events classified as B
%numberAB:number of the events classified as C
%numbers:number of the events classified as S
%numberme:number of the events classified as M
%numbern:number of the events classified as N
%time_stvsrl:time corresponding the start frame of the second color-time corresponding the  end frame of the first color)
%event: Events type corresponding to each AOI
% final_Frame:All the frame information about all type of events(the same
% information of the first row of the final_decison structure)
%final_Time:All the time information about all type of events(the same
% information of the second row of the final_decison structure)
%iout:counter
%A1: All the information about A type of events
%B1:All the information about B type of events
%S1:All the information about S  type of events
%M1:All theinformation about M  type of events
%N1:All theinformation about N  type of events

%Note: depending upon  data user can change the conditions to classify
%events

%11/16/2017  Fatemehsadat Jamalidinan  created
%11/17/2017  Fatemehsadat Jamalidinan and Harpreet Kaur  updated for comments

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
new_aoig = cat(1, b_time{1,1}{:,2}); %find out aoi numbers of green,b_time{1,1} is  All Traces cell array from green Interval file
new_aoir = cat(1, b_time{1,2}{:,2});%find out aoi numbers of red,b_time{1,2} is  All Traces cell array from red Interval file

b_time_green=find(new_aoig==green(1,7)); %find out aoi number of green
b_time_red=find(new_aoir==green(1,7));%find out aoi number of red


green_time=b_time{1,1}{b_time_green,9};%find corresponding times
red_time=b_time{1,2}{b_time_red,9};%find corresponding times
try
  green_time=green_time-green_time(1);
  red_time=red_time-red_time(1);
catch
end
iinput=1;

event=[];
t_relstart=[];
t_overlap=[];
t_relrelease=[];
tt_relstart=[];
tt_overlap=[];
tt_relrelease=[];
numberA=0;
numberB=0;
numberAB=0;
numbers=0;
time_stvsrl=[];
frame_stvsrl=[];
d_g=[];
d_r=[];
d1_g=[];
d1_r=[];
ttt=1;
point=zeros(size(green,1));
point1=zeros(size(red,1));
final_Frame{iinput,1}=0;
final_Time{iinput,1}=0;
final_Frame{iinput,2}=0;
final_Time{iinput,2}=0;
final_Frame{iinput,3}=0;
final_Time{iinput,3}=0;
final_Frame{iinput,4}=0;
final_Time{iinput,4}=0;
final_Frame{iinput,5}=0;
final_Frame{iinput,6}=0;
final_Time{iinput,5}=0;
final_Time{iinput,6}=0;
final_Frame{iinput,7}=0;
final_Time{iinput,7}=0;
iout=iinput-1;

A1=[];
a1_c=1;
B1=[];
b1_c=1;
S1=[];
s1_c=1;
M1=[];
m1_c=1;
N1=[];
n1_c=1;

f=0;



%A=1 %B=2 %S=3
for i=1:size(green,1)
    event1=[];
    a=0;
    b=0;
    for j=1:size(red,1)
        
        %If E_start( green column 2) < E_start( red column 2)< E_end( green column 3) and
        %E_end( red column 3)> E_end( green column 3)--->Count as A event
        % t_relstart= E_start( red column 2)- E_start( green column 2)
        %t_overlap= E_end( green column 3)- E_start( red column 2)
        %t_relrelease= E_end( red column 3)- E_end( green column 3)
        
        if green_time(green(i,2))<red_time(red(j,2))
            
            if red_time(red(j,2))<green_time(green(i,3))
                if red_time(red(j,3))>green_time(green(i,3))
                    event1=[event1;'A'];
                    
                    point(i)=2;
                    point1(j)=2;
                    time_stvsrl(ttt)=red_time(red(j,2))-green_time(green(i,3));
                    frame_stvsrl(ttt)=(red(j,2))-(green(i,3));
                    ttt=ttt+1;
                    numberA=numberA+1;
                    a=a+1;
                    t_r=red(j,2)-green(i,2);%frame
                    tt_r=red_time(red(j,2))-green_time(green(i,2));
                    t_relstart=[t_relstart; t_r];
                    tt_relstart=[tt_relstart; tt_r];
                    t_o=green(i,3)-red(j,2);
                    tt_o=green_time(green(i,3))-red_time(red(j,2));
                    t_overlap=[t_overlap; t_o];
                    tt_overlap=[tt_overlap; tt_o];
                    t_r=red(j,3)-green(i,3);
                    tt_r=red_time(red(j,3))-green_time(green(i,3));
                    tt_relrelease=[tt_relrelease;tt_r];
                    t_relrelease=[t_relrelease;t_r];
                    clear t_r t_o tt_r tt_o
                    %                     d_r=red(j,4);
                    %                     d1_r=red(j,5);
                    %                     d_g=green(i,4);
                    %                     d1_g=green(i,5);
                    d_r=[d_r;red(j,4)];
                    d1_r=[d1_r;red(j,5)];
                    d_g=[d_g;green(i,4)];
                    d1_g=[d1_g;green(i,5)];
                    
                    
                    final_Frame{iinput,1}=t_relstart(end);
                    final_Time{iinput,1}=tt_relstart(end);
                    final_Frame{iinput,2}=t_overlap(end);
                    final_Time{iinput,2}=tt_overlap(end);
                    final_Frame{iinput,3}=t_relrelease(end);
                    final_Time{iinput,3}=tt_relrelease(end);
                    final_Frame{iinput,4}=green(1,7);
                    final_Time{iinput,4}=green(1,7);
                    final_Frame{iinput,5}=d_g(end);
                    final_Frame{iinput,6}=d_r(end);
                    final_Time{iinput,5}=d1_g(end);
                    final_Time{iinput,6}=d1_r(end);
                    final_Frame{iinput,7}= frame_stvsrl(ttt-1);
                    final_Time{iinput,7}=time_stvsrl(ttt-1);
                    iinput=iinput+1;
                    iout=iinput;
                    A1(a1_c,1)=green(i,7);
                    A1(a1_c,2)=tt_relstart(end);
                    A1(a1_c,3)=tt_overlap(end);
                    A1(a1_c,4)=tt_relrelease(end);
                    A1(a1_c,5)=time_stvsrl(ttt-1);
                    A1(a1_c,6)=d1_g(end);
                    A1(a1_c,7)=d1_r(end);
                    a1_c=a1_c+1;
                    %  if Red and Green file Column 1 =high (1,3,-3)
                    % If E_start( green column 2) < E_start( red column 2)< E_end( green column 3) and E_end( red column 3)< E_end( green column 3)
                    % Count as event B
                    % t_relstart= E_start( red column 2)- E_start( green column 2)
                    % t_overlap= delta t_red ( column 4)
                    % t_relrelease= E_end( red column 3)- E_end( green column 3) ( will come as negative number)
                elseif red_time(red(j,3))<green_time(green(i,3))
                    event1=[event1;'B'];
                    point(i)=2;
                    point1(j)=2;
                    numberB=numberB+1;
                    time_stvsrl(ttt)=red_time(red(j,2))-green_time(green(i,3));
                    frame_stvsrl(ttt)=(red(j,2))-(green(i,3));
                    ttt=ttt+1;
                    b=b+1;
                    t_r=red(j,2)-green(i,2);
                    tt_r=red_time(red(j,2))-green_time(green(i,2));
                    t_relstart=[t_relstart; t_r];
                    tt_relstart=[tt_relstart; tt_r];
                    t_o=red(j,4);
                    tt_o=(red(j,5));
                    tt_overlap=[tt_overlap; tt_o];
                    t_overlap=[t_overlap; t_o];
                    t_r=red(j,3)-green(i,3);
                    tt_r=red_time(red(j,3))-green_time(green(i,3));
                    tt_relrelease=[tt_relrelease;tt_r];
                    t_relrelease=[t_relrelease;t_r];
                    clear t_r t_o tt_r tt_o
                    d_r=[d_r;red(j,4)];
                    d1_r=[d1_r;red(j,5)];
                    d_g=[d_g;green(i,4)];
                    d1_g=[d1_g;green(i,5)];
                    
                    
                    final_Frame{iinput,1}=t_relstart(end);
                    final_Time{iinput,1}=tt_relstart(end);
                    final_Frame{iinput,2}=t_overlap(end);
                    final_Time{iinput,2}=tt_overlap(end);
                    final_Frame{iinput,3}=t_relrelease(end);
                    final_Time{iinput,3}=tt_relrelease(end);
                    final_Frame{iinput,4}=green(1,7);
                    final_Time{iinput,4}=green(1,7);
                    %                     final_Frame{iinput,5}=d_g;
                    %                     final_Frame{iinput,6}=d_r;
                    %                     final_Time{iinput,5}=d1_g;
                    %                     final_Time{iinput,6}=d1_r;
                    final_Frame{iinput,5}=d_g(end);
                    final_Frame{iinput,6}=d_r(end);
                    final_Time{iinput,5}=d1_g(end);
                    final_Time{iinput,6}=d1_r(end);
                    final_Frame{iinput,7}= frame_stvsrl(ttt-1);
                    final_Time{iinput,7}=time_stvsrl(ttt-1);
                    iinput=iinput+1;
                    iout=iinput;
                    
                    B1(b1_c,1)=green(i,7);
                    B1(b1_c,2)=tt_relstart(end);
                    B1(b1_c,3)=tt_overlap(end);
                    B1(b1_c,4)=tt_relrelease(end);
                    B1(b1_c,5)=time_stvsrl(ttt-1);
                    B1(b1_c,6)=d1_g(end);
                    B1(b1_c,7)=d1_r(end);
                    b1_c=b1_c+1;
                    
                end
            end
        end
    end
    countab=0;
    if(b>=1)
        if(a>0)
            xb=find(event1=='B');
            
            xa=find(event1=='A');
            
            ab=0;
            for tt=1:length(xb)
                for tt1=1:length(xa)
                    if(xb(tt)<xa(tt1))
                        ab=ab+1;
                        if(ab>=1)
                            countab=countab+1;
                            numberB=numberB-length(xb);
                            numberA=numberA-length(xa);
                            ab=0;
                            
                        end
                    end
                end
            end
        end
    end
    
    if(countab>=1)
        event1=['C'];
        
        numberAB=numberAB+1;
    end
    event=[event; event1];
    
    
end
for i=1:size(green,1)
    
%if((abs(green_time(green(i,2))-red_time(red(j,2)))<=delta_t)&&(abs(green_time(green(i,3))-red_time(red(j,3)))<=delta_t))
         %   if(green(i,5)<=delta_t1 && red(j,5)<=delta_t1)
    % t_relstart= E_start( red column 2)- E_start( green column 2)
    % t_overlap= delta t_red ( column 4)
    % t_relrelease= E_end( red column 3)- E_end( green column 3) ( will come as negative number)
    for j=1:size(red,1)
        if((abs(green_time(green(i,2))-red_time(red(j,2)))<=delta_t(1))&&(abs(green_time(green(i,3))-red_time(red(j,3)))<=delta_t(1)))
            if(green(i,5)<=delta_t(2) && red(j,5)<=delta_t(2))
                event=[event; 's'];
                point(i)=2;
                point1(j)=2;
                time_stvsrl(ttt)=red_time(red(j,2))-green_time(green(i,3));
                frame_stvsrl(ttt)=(red(j,2))-(green(i,3));
                ttt=ttt+1;
                numbers=numbers+1;
                t_r=red(j,2)-green(i,2);
                tt_r=red_time(red(j,2))-green_time(green(i,2));
                t_relstart=[t_relstart; t_r];
                tt_relstart=[tt_relstart; tt_r];
                
                t_o=red(j,4);
                tt_o=(red(j,5));
                tt_overlap=[tt_overlap; tt_o];
                t_overlap=[t_overlap; t_o];
                t_r=red(j,3)-green(i,3);
                tt_r=red_time(red(j,3))-green_time(green(i,3));
                tt_relrelease=[tt_relrelease;tt_r];
                t_relrelease=[t_relrelease;t_r];
                d_r=[d_r;red(j,4)];
                d1_r=[d1_r;red(j,5)];
                d_g=[d_g;green(i,4)];
                d1_g=[d1_g;green(i,5)];
                final_Frame{iinput,1}=t_relstart(end);
                final_Time{iinput,1}=tt_relstart(end);
                final_Frame{iinput,2}=t_overlap(end);
                final_Time{iinput,2}=tt_overlap(end);
                final_Frame{iinput,3}=t_relrelease(end);
                final_Time{iinput,3}=tt_relrelease(end);
                final_Frame{iinput,4}=green(1,7);
                final_Time{iinput,4}=green(1,7);
                final_Frame{iinput,5}=d_g(end);
                final_Frame{iinput,6}=d_r(end);
                final_Time{iinput,5}=d1_g(end);
                final_Time{iinput,6}=d1_r(end);
                final_Frame{iinput,7}= frame_stvsrl(ttt-1);
                final_Time{iinput,7}=time_stvsrl(ttt-1);
                iinput=iinput+1;
                iout=iinput;
                S1(s1_c,1)=green(i,7);
                S1(s1_c,2)=tt_relstart(end);
                S1(s1_c,3)=tt_overlap(end);
                S1(s1_c,4)=tt_relrelease(end);
                S1(s1_c,5)=time_stvsrl(ttt-1);
                S1(s1_c,6)=d1_g(end);
                S1(s1_c,7)=d1_r(end);
                s1_c=s1_c+1;
                
            end
        end
    end
    
    
end



me=0;
kk=0;
l=0;
for i=1:size(green,1)
    for j=1:size(red,1)
        l=j+1;
        if(l>size(red,1))
            l=size(red,1);
        end
         temp1=red_time(red(j,2))-green_time(green(i,3));
        temp2=green_time(green(i,2))-red_time(red(j,3));
        if(point(i)==0)
            
            
            if(((red_time(red(j,2))<green_time(green(i,2)) && red_time(red(j,3))>green_time(green(i,3)))||(green_time(green(i,2))> red_time(red(j,3)) && green_time(green(i,3))< red_time(red(1,2))))||(temp1>userinput)||(temp2>userinput))
                event=[event; 'F'];
                point(i)=2;
                point1(j)=2;
                t_r=0;
                tt_r=0;
                t_relstart=[t_relstart; t_r];
                tt_relstart=[tt_relstart; tt_r];
                tt_overlap=[tt_overlap; 0];
                t_overlap=[t_overlap;0];
                
                t_r=0;
                tt_r=0;
                tt_relrelease=[tt_relrelease;tt_r];
                t_relrelease=[t_relrelease;t_r];
                d_r=[d_r;red(j,4)];
                d1_r=[d1_r;red(j,5)];
                d_g=[d_g;green(i,4)];
                d1_g=[d1_g;green(i,5)];
                
                time_stvsrl(ttt)=0;
                frame_stvsrl(ttt)=0;
                f=f+1;
                
                
%                 %%%%%%%%%%%%%%%%%%%%%%%
%                 final_Frame{iinput,1}=t_relstart(end);
%                 final_Time{iinput,1}=tt_relstart(end);
%                 final_Frame{iinput,2}=t_overlap(end);
%                 final_Time{iinput,2}=tt_overlap(end);
%                 final_Frame{iinput,3}=t_relrelease(end);
%                 final_Time{iinput,3}=tt_relrelease(end);
%                 final_Frame{iinput,4}=green(1,7);
%                 final_Time{iinput,4}=green(1,7);
%                 final_Frame{iinput,5}=d_g(end);
%                 final_Frame{iinput,6}=d_r(end);
%                 final_Time{iinput,5}=d1_g(end);
%                 final_Time{iinput,6}=d1_r(end);
%                 final_Frame{iinput,7}= 0;
%                 final_Time{iinput,7}=0;
%                 iinput=iinput+1;
%                 iout=iinput;
%                 
                %                     M1(m1_c,1)=green(i,7);
                %                     M1(m1_c,2)=tt_relstart(end);
                %                     M1(m1_c,3)=tt_overlap(end);
                %                     M1(m1_c,4)=tt_relrelease(end);
                %                     M1(m1_c,5)=time_stvsrl(ttt-1);
                %                     M1(m1_c,6)=d1_g;
                %                     M1(m1_c,7)=d1_r;
                %                     m1_c=m1_c+1;
                
            else
                
                temp=red_time(red(j,2))-green_time(green(i,3));
                temp1=(red(j,2))-(green(i,3));
                if(temp<userinput)
                    if(temp>=0)
                        if( point1(j)==0)
                            if(j>kk)
                                kk=j;
                                
                                event=[event; 'M'];
                                point(i)=2;
                                point1(j)=2;
                                t_r=red(j,2)-green(i,2);
                                tt_r=red_time(red(j,2))-green_time(green(i,2));
                                t_relstart=[t_relstart; t_r];
                                tt_relstart=[tt_relstart; tt_r];
                                tt_overlap=[tt_overlap; 0];
                                t_overlap=[t_overlap;0];
                                
                                t_r=red(j,3)-green(i,3);
                                tt_r=red_time(red(j,3))-green_time(green(i,3));
                                tt_relrelease=[tt_relrelease;tt_r];
                                t_relrelease=[t_relrelease;t_r];
                                d_r=[d_r;red(j,4)];
                                d1_r=[d1_r;red(j,5)];
                                d_g=[d_g;green(i,4)];
                                d1_g=[d1_g;green(i,5)];
                                
                                time_stvsrl(ttt)=temp;
                                frame_stvsrl(ttt)=temp1;
                                me=me+1;
                                ttt=ttt+1;
                                
                                %%%%%%%%%%%%%%%%%%%%%%%
                                final_Frame{iinput,1}=t_relstart(end);
                                final_Time{iinput,1}=tt_relstart(end);
                                final_Frame{iinput,2}=t_overlap(end);
                                final_Time{iinput,2}=tt_overlap(end);
                                final_Frame{iinput,3}=t_relrelease(end);
                                final_Time{iinput,3}=tt_relrelease(end);
                                final_Frame{iinput,4}=green(1,7);
                                final_Time{iinput,4}=green(1,7);
                                final_Frame{iinput,5}=d_g(end);
                                final_Frame{iinput,6}=d_r(end);
                                final_Time{iinput,5}=d1_g(end);
                                final_Time{iinput,6}=d1_r(end);
                                final_Frame{iinput,7}= frame_stvsrl(ttt-1);
                                final_Time{iinput,7}=time_stvsrl(ttt-1);
                                iinput=iinput+1;
                                iout=iinput;
                                
                                M1(m1_c,1)=green(i,7);
                                M1(m1_c,2)=tt_relstart(end);
                                M1(m1_c,3)=tt_overlap(end);
                                M1(m1_c,4)=tt_relrelease(end);
                                M1(m1_c,5)=time_stvsrl(ttt-1);
                                M1(m1_c,6)=d1_g(end);
                                M1(m1_c,7)=d1_r(end);
                                m1_c=m1_c+1;
                                %%%%%%%%%%%%%%%%%%%%%%
                            else
                                kk=j;
                                ttt=ttt-1;
                                time_stvsrl(ttt)=temp;
                                frame_stvsrl(ttt)=temp1;
                                ttt=ttt+1;
                            end
                        else
                            
                            break;
                        end
                    end
                end
            end
        end
    end
end

numberme=me;



me=0;
kk=0;

for j=1:size(red,1)
    for i=1:size(green,1)
        if( point1(j)==0)
            temp=green_time(green(i,2))-red_time(red(j,3));
            temp1=(green(i,2))-(red(j,3));
            if(temp<userinput)
                if(temp>=0)
                    if(point(i)==0)
                        if(j>kk)
                            kk=j;
                            point(i)=2;
                            point1(j)=2;
                            event=[event; 'N'];
                            
                            t_r=red(j,2)-green(i,2);
                            tt_r=red_time(red(j,2))-green_time(green(i,2));
                            t_relstart=[t_relstart; t_r];
                            tt_relstart=[tt_relstart; tt_r];
                            tt_overlap=[tt_overlap; 0];
                            t_overlap=[t_overlap;0];
                            
                            t_r=red(j,3)-green(i,3);
                            tt_r=red_time(red(j,3))-green_time(green(i,3));
                            tt_relrelease=[tt_relrelease;tt_r];
                            t_relrelease=[t_relrelease;t_r];
                            d_r=[d_r;red(j,4)];
                            d1_r=[d1_r;red(j,5)];
                            d_g=[d_g;green(i,4)];
                            d1_g=[d1_g;green(i,5)];
                            
                             time_stvsrl(ttt)=red_time(red(j,2))-green_time(green(i,3));
                            frame_stvsrl(ttt)=(red(j,2))-(green(i,3));
                            me=me+1;
                            ttt=ttt+1;
                            
                            %%%%%%%%%%%%%%%%%%%%%%%
                            final_Frame{iinput,1}=t_relstart(end);
                            final_Time{iinput,1}=tt_relstart(end);
                            final_Frame{iinput,2}=t_overlap(end);
                            final_Time{iinput,2}=tt_overlap(end);
                            final_Frame{iinput,3}=t_relrelease(end);
                            final_Time{iinput,3}=tt_relrelease(end);
                            final_Frame{iinput,4}=green(1,7);
                            final_Time{iinput,4}=green(1,7);
                            final_Frame{iinput,5}=d_g(end);
                            final_Frame{iinput,6}=d_r(end);
                            final_Time{iinput,5}=d1_g(end);
                            final_Time{iinput,6}=d1_r(end);
                            final_Frame{iinput,7}= frame_stvsrl(ttt-1);
                            final_Time{iinput,7}=time_stvsrl(ttt-1);
                            iinput=iinput+1;
                            iout=iinput;
                            
                            N1(n1_c,1)=green(i,7);
                            N1(n1_c,2)=tt_relstart(end);
                            N1(n1_c,3)=tt_overlap(end);
                            N1(n1_c,4)=tt_relrelease(end);
                            N1(n1_c,5)=time_stvsrl(ttt-1);
                            N1(n1_c,6)=d1_g(end);
                            N1(n1_c,7)=d1_r(end);
                            n1_c=n1_c+1;
                            %%%%%%%%%%%%%%%%%%%%%%
                        else
                            kk=j;
                            ttt=ttt-1;
                            time_stvsrl(ttt)=red_time(red(j,2))-green_time(green(i,3));
                            frame_stvsrl(ttt)=(red(j,2))-(green(i,3));
                            ttt=ttt+1;
                        end
                    else
                        break;
                    end
                end
            end
        end
    end
end

numbern=me;




final_decision{1,1}=event;
final_decision{2,1}=event;
final_decision{1,2}=t_relstart;
final_decision{2,2}=tt_relstart;
final_decision{1,3}=t_overlap;
final_decision{2,3}=tt_overlap;
final_decision{1,4}=t_relrelease;
final_decision{2,4}=tt_relrelease;
final_decision{1,5}=green(1,7);
final_decision{2,5}=green(1,7);
final_decision{1,6}=d_g;
final_decision{1,7}=d_r;
final_decision{2,6}=d1_g;
final_decision{2,7}=d1_r;
final_decision{1,8}=frame_stvsrl;
final_decision{2,8}=time_stvsrl;

% final_decision{1,1}='F';
% final_decision{2,1}='F';
% final_decision{1,2}=0;
% final_decision{2,2}=0;
% final_decision{1,3}=0;
% final_decision{2,3}=0;
% final_decision{1,4}=0;
% final_decision{2,4}=0;
% final_decision{1,5}=green(1,7);
% final_decision{2,5}=green(1,7);
% final_decision{1,6}=green(i,4);
% final_decision{1,7}=red(j,4);
% final_decision{2,6}=green(i,5);
% final_decision{2,7}=red(j,5);
% final_decision{1,8}=0;
% final_decision{2,8}=0;
% numberA=0;numberB=0;numberAB=0;numbers=0;numberme=0;numbern=0;time_stvsrl=0;event='F'; final_Frame=0;final_Time=0;iout=0;A1=0;B1=0;S1=0;M1=0;N1=0;