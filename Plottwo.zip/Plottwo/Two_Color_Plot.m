function varargout = Two_Color_Plot(varargin)
%2017  Fatemehsadat Jamalidinan  created
%TWO_COLOR_PLOT MATLAB code file for Two_Color_Plot.fig
%      TWO_COLOR_PLOT, by itself, creates a new TWO_COLOR_PLOT or raises the existing
%      singleton*.
%
%      H = TWO_COLOR_PLOT returns the handle to a new TWO_COLOR_PLOT or the handle to
%      the existing singleton*.
%
%      TWO_COLOR_PLOT('Property','Value',...) creates a new TWO_COLOR_PLOT using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to Two_Color_Plot_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      TWO_COLOR_PLOT('CALLBACK') and TWO_COLOR_PLOT('CALLBACK',hObject,...) call the
%      local function named CALLBACK in TWO_COLOR_PLOT.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Two_Color_Plot

% Last Modified by GUIDE v2.5 29-Nov-2017 12:29:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Two_Color_Plot_OpeningFcn, ...
                   'gui_OutputFcn',  @Two_Color_Plot_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end
try
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
catch
    error=1;
end
% End initialization code - DO NOT EDIT


% --- Executes just before Two_Color_Plot is made visible.
function Two_Color_Plot_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)
imshow('bg_header.png')
% Choose default command line output for Two_Color_Plot
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


set(handles.Time, 'Value',0)
set(handles.Frame, 'Value',0)
set(handles.Out_dir,'String','');
set(handles.red_dir,'String','');
set(handles.Green_dir,'String','');


% UIWAIT makes Two_Color_Plot wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Two_Color_Plot_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Time.
function Time_Callback(hObject, eventdata, handles)
% hObject    handle to Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB

    
% Hint: get(hObject,'Value') returns toggle state of Time


% --- Executes on button press in Input_green.
function Input_green_Callback(hObject, eventdata, handles)
% hObject    handle to Input_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green a_red b_red OUTPUT_DIR;

% hObject    handle to In_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
[fn, fp]=uigetfile('*.mat', 'Select the 1st Interval .mat File to Analyze', 'Multiselect', 'off');
% fp_baseout = uigetdir(fp, 'Select a folder to write images and step counts to:');


%If only one file selected, MATLAB returns character vector.
%If more than one, MATLAB returns cell array of character vectors...
%Need to put it into a cell array for the downstream analysis.

eval(['load ' [fp fn] ' -mat']);
a_green=Intervals.CumulativeIntervalArray;
b_green=Intervals.AllTracesCellArray;
set(handles.Out_dir,'String','');
set(handles.Green_dir,'String',[fp fn]);
catch
   msgbox('The machine can not read the interval .mat file you wish to analyze');
    error=1;
    set(handles.Green_dir,'String','');
end



% --- Executes on button press in analyze.
function analyze_Callback(hObject, eventdata, handles)
% hObject    handle to analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global a_green b_green a_red b_red OUTPUT_DIR;
set(handles.busy,'String','busy')
a{:,1}=b_green;
a{:,2}=b_red;
fp_baseout=OUTPUT_DIR;
if(get(handles.Frame, 'Value')==1)

    final_numSpots=0;
    for k=1:2

        numSpots=max(cell2mat(a{:,k}(:,2)));
        if(numSpots> final_numSpots)
            final_numSpots=numSpots;
        end
       
    end
    colorspec = {[0 1 0]; [1 0 0]; [0 1 1]; ...
  [0.4 0.4 0.4]; [0.2 0.2 0.2]};
    
    for i=1:final_numSpots
        vbn=0;
        ttt=0;
        h=figure;
    for k=1:2
       try
          
           temp=cell2mat(a{:,k}(:,2));
           temp_num=find(temp==i);
           cv=a{1,k}{temp_num,12};
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %Make smallish images
           if(k==1)
               nm=colorspec{1};
           elseif(k==2)
               nm=colorspec{2};
           elseif(k==3)
               nm=colorspec{3};
           elseif(k==4)
               nm=colorspec{4};
           elseif(k==5)
               nm=colorspec{5};
           end
      
          plot(cv(:,1),cv(:,2),'Color',nm); hold on
          ttt=ttt+1;
         
            xlabel('Frame');
            ylabel('Intensity');
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
          
           clear cv
       catch
            vbn=vbn+1;
       end
    end
    if(vbn<2)
    try
     legend('show');
            %legend('Location','southwest');

            % Print out labeled graph to file and print out step indices
            fpout = strcat(fp_baseout);
            if(ttt>=2)
             filename_raw = strcat(fpout, '/',['frame_' num2str(i)], '.fig');
            % print(filename_raw,'-dsvg')
           savefig(filename_raw);
            end
            

    catch
    end
    end
    close(h);
    end

end
if(get(handles.Time, 'Value')==1)
 final_numSpots=0;
    for k=1:2
      
        numSpots=max(cell2mat(a{:,k}(:,2)));
        if(numSpots> final_numSpots)
            final_numSpots=numSpots;
        end
       % [filepath, filename, ext] = fileparts(fn); 
    end
    colorspec = {[0 1 0]; [1 0 0]; [0 1 1]; ...
  [0.4 0.4 0.4]; [0.2 0.2 0.2]};
    
    for i=1:final_numSpots
        vbn=0;
        ttt=0;
        h=figure;
    for k=1:2
       try
          
           temp=cell2mat(a{:,k}(:,2));
           temp_num=find(temp==i);
           cv=a{1,k}{temp_num,12};
           cv1=(a{1,k}{temp_num,9}-a{1,k}{temp_num,9}(1));
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           %Make smallish images
           if(k==1)
               nm=colorspec{1};
           elseif(k==2)
               nm=colorspec{2};
           elseif(k==3)
               nm=colorspec{3};
           elseif(k==4)
               nm=colorspec{4};
           elseif(k==5)
               nm=colorspec{5};
           end
          
          plot(cv1,cv(:,2),'Color',nm); hold on
          ttt=ttt+1;
         
            xlabel('Time');
            ylabel('Intensity');
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
          
           clear cv
       catch
            vbn=vbn+1;
       end
    end
    if(vbn<2)
    try
     legend('show');
            %legend('Location','southwest');

            % Print out labeled graph to file and print out step indices
            fpout = strcat(fp_baseout);
            if(ttt>=2)
             filename_raw = strcat(fpout, '/',['Time_' num2str(i)], '.fig');
            % print(filename_raw,'-dsvg')
            savefig(filename_raw);
            end

    catch
    end
    end
    close(h);
    end   
    
end
set(handles.busy,'String','')


% --- Executes on button press in Frame.
function Frame_Callback(hObject, eventdata, handles)
% hObject    handle to Frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB

% Hint: get(hObject,'Value') returns toggle state of Frame




% --- Executes on button press in output.
function output_Callback(hObject, eventdata, handles)
% hObject    handle to output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green a_red b_red OUTPUT_DIR;

 OUTPUT_DIR = uigetdir('Select a folder to write images and results to:');

   set(handles.Out_dir,'String',OUTPUT_DIR); 
    if(OUTPUT_DIR==0)
        set(handles.Out_dir,'String',''); 
    end

  


function red_dir_Callback(hObject, eventdata, handles)
% hObject    handle to red_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of red_dir as text
%        str2double(get(hObject,'String')) returns contents of red_dir as a double


% --- Executes during object creation, after setting all properties.
function red_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to red_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Input_red.
function Input_red_Callback(hObject, eventdata, handles)
% hObject    handle to Input_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global a_green b_green a_red b_red OUTPUT_DIR;
try
% hObject    handle to In_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[fn, fp]=uigetfile('*.mat', 'Select the 1st Interval .mat File to Analyze', 'Multiselect', 'off');
% fp_baseout = uigetdir(fp, 'Select a folder to write images and step counts to:');

eval(['load ' [fp fn] ' -mat']);

a_red=Intervals.CumulativeIntervalArray;
b_red=Intervals.AllTracesCellArray;
set(handles.Out_dir,'String','');
set(handles.red_dir,'String',[fp fn]);
catch
    msgbox('The machine can not read the interval .mat file you wish to analyze');
    set(handles.red_dir,'String','');
end



% --- Executes during object creation, after setting all properties.
function Input_red_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Input_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function Green_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Green_dir as text
%        str2double(get(hObject,'String')) returns contents of Green_dir as a double


% --- Executes during object creation, after setting all properties.
function Green_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Out_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Out_dir as text
%        str2double(get(hObject,'String')) returns contents of Out_dir as a double


% --- Executes during object creation, after setting all properties.
function Out_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in usermanual.
function usermanual_Callback(hObject, eventdata, handles)
% hObject    handle to usermanual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    winopen('TwoColorPlot.pdf');
catch
    system('open TwoColorPlot.pdf');
end