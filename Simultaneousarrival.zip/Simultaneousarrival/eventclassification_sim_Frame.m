
function[final_decision,numberA,numberB,numberC,numberF,numberD, final_Frame,final_Time,iout,A1,B1,C1,D1]= eventclassification_sim_Frame(green,red,b_time,userinput,delta_f)
%function[final_decision,numberA,numberB,numberC,numberF,numberD,event, final_Frame,final_Time,iout,A1,B1,C1,D1]= eventclassification_sim_Frame(green,red,b_time,userinput,delta_f)
%
% first file is assighned as green by default
% Second file is assighned as red by default
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function classifies two color colocalization events based on
% simultaneous arrival and departure vs the  simultaneous arrival and
% variation in the departure frame
% Input:
%green: contains all the information from Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers) for first color.
%red:contains all the information from  Cumulative Interval Array corresponding the high values(which can be -3,3 1 or any combination of those
%numbers) for the second color.
%b_time: the corresponding time information from cell traces array
%userinput:% if the  difference between the initial frames of two colors interval is higher than this value we take it as a 'F' event 
%delta_f:Decision parameter for the classification and it is the upper frame limit
%to descide if the arrival of the two events is simultaneous or not.
%output
%final_decision:Output information will be saved in this structure such as 
%Frame:(events types(A, B, C, D,F))(relative start frame)(Frame_overlap)(relative release frame)(#AoI)(delta Frame_color one)(delta Frame_color2)
%Time:(events types(A, B, C, D,F))(relative start time)(overlap time)(relative release time)(#AoI)(delta Time_color one)(delta time_color2)
%A type: both color events appeared and departed simultaneouly
%B type: both color events appeared simultaneouly but 2nd color departed
%later than the 1st color.
%C type: both color events appeared simultaneouly but 1st color departed
%later than the 2nd color
%D type: both color events appeared simultaneouly but none of them left
%F type: if both color events are started at the different time
%numberA:number of the events classified as A
%numberB:number of the events classified as B
%numberC:number of the events classified as C
%numberD:number of the events classified as D
%numberF:number of the events that are flagged
% final_Frame:All the frame information about all type of events(the same
% information of the first row of the final_decison structure)
%final_Time:All the time information about all type of events(the same
% information of the second row of the final_decison structure)
%iout:counter
%A1: All the information about A types of event
%B1:All the information about B types of event
%C1:All the information about C types of event
%D1:All theinformation about D types of event

%Note: depending upon  data user can change the conditions to classify
%events

%11/16/2017  Fatemehsadat Jamalidinan  created
%11/17/2017  Fatemehsadat Jamalidinan and Harpreet Kaur  updated for comments

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 



new_aoig = cat(1, b_time{1,1}{:,2}); %find out aoi numbers of green,b_time{1,1} is  All Traces cell array from green Interval file
new_aoir = cat(1, b_time{1,2}{:,2});%find out aoi numbers of red,b_time{1,2} is  All Traces cell array from red Interval file

b_time_green=find(new_aoig==green(1,7)); %find out aoi number of green
b_time_red=find(new_aoir==green(1,7));%find out aoi number of red


green_time=b_time{1,1}{b_time_green,9};%find corresponding times
red_time=b_time{1,2}{b_time_red,9};%find corresponding times
try
  green_time=green_time-green_time(1);
  red_time=red_time-red_time(1);
catch
end
number_of_peak_green=size(green,1);%number_of_peak_green
number_of_peak_red=size(red,1);%number_of_peak_red
iinput=1;

event=[];
t_relstart=[];
t_overlap=[];
t_relrelease=[];
tt_relstart=[];
tt_overlap=[];
tt_relrelease=[];
numberA=0;
numberB=0;
numberC=0;
numberF=0;
numberD=0;
time_stvsrl=[];
frame_stvsrl=[];
d_g=[];
d_r=[];
d1_g=[];
d1_r=[];
ttt=1;
point=zeros(size(green,1));
point1=zeros(size(red,1));
final_Frame{iinput,1}=0;
final_Time{iinput,1}=0;
final_Frame{iinput,2}=0;
final_Time{iinput,2}=0;
final_Frame{iinput,3}=0;
final_Time{iinput,3}=0;
final_Frame{iinput,4}=0;
final_Time{iinput,4}=0;
final_Frame{iinput,5}=0;
final_Frame{iinput,6}=0;
final_Time{iinput,5}=0;
final_Time{iinput,6}=0;
final_Frame{iinput,7}=0;
final_Time{iinput,7}=0;
iout=iinput-1;

A1=[];
a1_c=1;
B1=[];
b1_c=1;
C1=[];
c1_c=1;
F1=[];
f1_c=1;
D1=[];
d1_c=1;


event1=[];
%A=1 %B=2 %S=3
for i=1:size(green,1)
    
    a=0;
    b=0;
    for j=1:size(red,1)
        if(green(i,1)==3&& red(j,1)==3)  % check if event type is  +3
            if (abs(red(j,2)-green(i,2))<=delta_f)% check if the initial frame diffrence between 2 colors arrival frame numbers is within decision parameters(delta_f)
                event1=[event1;'D'];
                
                point(i)=2;
                point1(j)=2;
                
                numberD=numberD+1;
                
                t_r=red(j,2)-green(i,2);%relative arrival frame of red with respect to green
                tt_r=red_time(red(j,2))-green_time(green(i,2));%relative arrival time of red with respect to green
                t_relstart=[t_relstart; t_r]; %relative arrival frames of red with respect to green
                tt_relstart=[tt_relstart; tt_r];%relative arrival times of red with respect to green
                t_o=green(i,4);%Number of overlap frame
                tt_o=(green(i,5));%Number of overlap time
                t_overlap=[t_overlap; t_o];%Number of overlap frames
                tt_overlap=[tt_overlap; tt_o];%Number of overlap times
                t_r=red(j,3)-green(i,3);%relative release frame of red with respect to green
                tt_r=red_time(red(j,3))-green_time(green(i,3));%relative release time of red with respect to green
                tt_relrelease=[tt_relrelease;tt_r];%relative release times of red with respect to green
                t_relrelease=[t_relrelease;t_r];%relative release frames of red with respect to green
                clear t_r t_o tt_r tt_o
                d_r=[d_r;red(j,4)];%Frame Interval vector for red corresponding to the event being classified
                d1_r=[d1_r;red(j,5)];%Time Interval vector for red corresponding to the event being classified
                d_g=[d_g;green(i,4)];%Frame Interval vector for green corresponding to the event being classified
                d1_g=[d1_g;green(i,5)];%Time Interval vector for green corresponding to the event being classified
                
                final_Frame{iinput,1}=t_relstart(end); %output for the  relative arrival frame
                final_Time{iinput,1}=tt_relstart(end);%output for the  relative arrival time
                final_Frame{iinput,2}=t_overlap(end);%output for the overlap frame
                final_Time{iinput,2}=tt_overlap(end);%output for the overlap time
                final_Frame{iinput,3}=t_relrelease(end);%output for the  relative release frame
                final_Time{iinput,3}=tt_relrelease(end);%output for the relative release  time
                final_Frame{iinput,4}=green(1,7); %corresponding AoI number
                final_Time{iinput,4}=green(1,7); %corresponding AoI number
                final_Frame{iinput,5}=d_g(end);%output for the corresponding Frame Interval for green
                final_Frame{iinput,6}=d_r(end);%output for the corresponding Frame Interval for red
                final_Time{iinput,5}=d1_g(end);%output for the corresponding time Interval for green
                final_Time{iinput,6}=d1_r(end);%output for the corresponding time Interval for red
                
                iinput=iinput+1; % counter for final_Time
                iout=iinput;
                
                %% % the info output of D type of event
                D1(a1_c,1)=green(i,7);
                D1(a1_c,2)=tt_relstart(end);
                D1(a1_c,3)=tt_overlap(end);
                D1(a1_c,4)=tt_relrelease(end);
                D1(a1_c,5)=d1_g(end);
                D1(a1_c,6)=d1_r(end);
                d1_c=d1_c+1;
                
            end
            
            
        elseif (abs(red(j,2)-green(i,2))<=delta_f) % check if the diffrence between  start frame numbers of the both types of events(red/green) is within decision parameters(delta_f)
            if (abs(red(j,3)-green(i,3))<=delta_f) % check if the diffrence between  end frame numbers of the both types of events(red/green) is within decision parameters(delta_f)
                event1=[event1;'A'];
                
                point(i)=2;
                point1(j)=2;
                
                numberA=numberA+1;
                a=a+1;
                t_r=red(j,2)-green(i,2);%relative arrival frame of red with respect to green
                tt_r=red_time(red(j,2))-green_time(green(i,2));%relative arrival time of red with respect to green
                t_relstart=[t_relstart; t_r];%relative arrival frames of red with respect to green
                tt_relstart=[tt_relstart; tt_r];%relative arrival times of red with respect to green
                t_o=green(i,4);%Number of overlap frame
                tt_o=(green(i,5));%overlap time
                t_overlap=[t_overlap; t_o];%Number of overlap frames
                tt_overlap=[tt_overlap; tt_o];%overlap times
                t_r=red(j,3)-green(i,3);%relative release frame of red with respect to green
                tt_r=red_time(red(j,3))-green_time(green(i,3));%relative release time of red with respect to green
                tt_relrelease=[tt_relrelease;tt_r];%relative release times of red with respect to green
                t_relrelease=[t_relrelease;t_r];%relative release frames of red with respect to green
                clear t_r t_o tt_r tt_o
                d_r=[d_r;red(j,4)];%Frame Interval vector for red corresponding to the event being classified
                d1_r=[d1_r;red(j,5)];%Time Interval vector for red corresponding to the event being classified
                d_g=[d_g;green(i,4)];%Frame Interval vector for green corresponding to the event being classified
                d1_g=[d1_g;green(i,5)];%Time Interval vector for green corresponding to the event being classified
                
                
                final_Frame{iinput,1}=t_relstart(end); %output for the  relative arrival frame
                final_Time{iinput,1}=tt_relstart(end);%output for the  relative arrival time
                final_Frame{iinput,2}=t_overlap(end);%output for the overlap frame
                final_Time{iinput,2}=tt_overlap(end);%output for the overlap time
                final_Frame{iinput,3}=t_relrelease(end);%output for the  relative release frame
                final_Time{iinput,3}=tt_relrelease(end);%output for the relative release  time
                final_Frame{iinput,4}=green(1,7); %corresponding AoI number
                final_Time{iinput,4}=green(1,7); %corresponding AoI number
                final_Frame{iinput,5}=d_g(end);%output for the corresponding Frame Interval for green
                final_Frame{iinput,6}=d_r(end);%output for the corresponding Frame Interval for red
                final_Time{iinput,5}=d1_g(end);%output for the corresponding time Interval for green
                final_Time{iinput,6}=d1_r(end);%output for the corresponding time Interval for red
                
                
                iinput=iinput+1; % counter for final_Time
                iout=iinput;
                %%  %% % the info output of A type of event
                A1(a1_c,1)=green(i,7);
                A1(a1_c,2)=tt_relstart(end);
                A1(a1_c,3)=tt_overlap(end);
                A1(a1_c,4)=tt_relrelease(end);
                
                A1(a1_c,5)=d1_g(end);
                A1(a1_c,6)=d1_r(end);
                a1_c=a1_c+1;
                %%
                
            elseif ((red(j,3)-green(i,3))>delta_f)% diffrence between the end frame for those events is not within the decision paramter(delta_f) it will test for the end frame for red event is greater than the end frame for green event 
                event1=[event1;'B'];
                point(i)=2;
                point1(j)=2;
                numberB=numberB+1;
                b=b+1;
                t_r=red(j,2)-green(i,2);%relative arrival frame of red with respect to green
                tt_r=red_time(red(j,2))-green_time(green(i,2));%relative arrival time of red with respect to green
                t_relstart=[t_relstart; t_r];%relative arrival frames of red with respect to green
                tt_relstart=[tt_relstart; tt_r];%relative arrival times of red with respect to green
                t_o=green(i,4);%Number of overlap frame
                tt_o=(green(i,5));%overlap time
                 t_overlap=[t_overlap; t_o];%Number of overlap frames
                tt_overlap=[tt_overlap; tt_o];%overlap times
               t_r=red(j,3)-green(i,3);%relative release frame of red with respect to green
                tt_r=red_time(red(j,3))-green_time(green(i,3));%relative release time of red with respect to green
                tt_relrelease=[tt_relrelease;tt_r];%relative release times of red with respect to green
                t_relrelease=[t_relrelease;t_r];%relative release frames of red with respect to green
                clear t_r t_o tt_r tt_o
           
                d_r=[d_r;red(j,4)];%Frame Interval vector for red corresponding to the event being classified
                d1_r=[d1_r;red(j,5)];%Time Interval vector for red corresponding to the event being classified
                d_g=[d_g;green(i,4)];%Frame Interval vector for green corresponding to the event being classified
                d1_g=[d1_g;green(i,5)];%Time Interval vector for green corresponding to the event being classified
                
               final_Frame{iinput,1}=t_relstart(end); %output for the  relative arrival frame
                final_Time{iinput,1}=tt_relstart(end);%output for the  relative arrival time
                final_Frame{iinput,2}=t_overlap(end);%output for the overlap frame
                final_Time{iinput,2}=tt_overlap(end);%output for the overlap time
                final_Frame{iinput,3}=t_relrelease(end);%output for the  relative release frame
                final_Time{iinput,3}=tt_relrelease(end);%output for the relative release  time
                final_Frame{iinput,4}=green(1,7); %corresponding AoI number
                final_Time{iinput,4}=green(1,7); %corresponding AoI number
                final_Frame{iinput,5}=d_g(end);%output for the corresponding Frame Interval for green
                final_Frame{iinput,6}=d_r(end);%output for the corresponding Frame Interval for red
                final_Time{iinput,5}=d1_g(end);%output for the corresponding time Interval for green
                final_Time{iinput,6}=d1_r(end);%output for the corresponding time Interval for red
                iinput=iinput+1;
                iout=iinput;
                %% %%  %% % the info output of B type of event 
                
                B1(b1_c,1)=green(i,7);
                B1(b1_c,2)=tt_relstart(end);
                B1(b1_c,3)=tt_overlap(end);
                B1(b1_c,4)=tt_relrelease(end);
                
                B1(b1_c,5)=d1_g(end);
                B1(b1_c,6)=d1_r(end);
                b1_c=b1_c+1;
                %% 
            elseif((red(j,3)-green(i,3))<(-1*delta_f)) % diffrence between the end frame for those events is not within the decision paramter(delta_f) it will test for the end frame for red event is smaller than the end frame for green event
                event1=[event1;'C'];
                point(i)=2;
                point1(j)=2;
                numberC=numberC+1;
                t_r=red(j,2)-green(i,2);%relative arrival frame of red with respect to green
                tt_r=red_time(red(j,2))-green_time(green(i,2));%relative arrival time of red with respect to green
                t_relstart=[t_relstart; t_r];%relative arrival frames of red with respect to green
                tt_relstart=[tt_relstart; tt_r];%relative arrival times of red with respect to green
                t_o=red(j,4);%Number of overlap frame
                tt_o=(red(j,5));%overlap time
                 t_overlap=[t_overlap; t_o];%Number of overlap frames
                tt_overlap=[tt_overlap; tt_o];%overlap times
               t_r=red(j,3)-green(i,3);%relative release frame of red with respect to green
                tt_r=red_time(red(j,3))-green_time(green(i,3));%relative release time of red with respect to green
                tt_relrelease=[tt_relrelease;tt_r];%relative release times of red with respect to green
                t_relrelease=[t_relrelease;t_r];%relative release frames of red with respect to green
                clear t_r t_o tt_r tt_o
           
                d_r=[d_r;red(j,4)];%Frame Interval vector for red corresponding to the event being classified
                d1_r=[d1_r;red(j,5)];%Time Interval vector for red corresponding to the event being classified
                d_g=[d_g;green(i,4)];%Frame Interval vector for green corresponding to the event being classified
                d1_g=[d1_g;green(i,5)];%Time Interval vector for green corresponding to the event being classified
                
               final_Frame{iinput,1}=t_relstart(end); %output for the  relative arrival frame
                final_Time{iinput,1}=tt_relstart(end);%output for the  relative arrival time
                final_Frame{iinput,2}=t_overlap(end);%output for the overlap frame
                final_Time{iinput,2}=tt_overlap(end);%output for the overlap time
                final_Frame{iinput,3}=t_relrelease(end);%output for the  relative release frame
                final_Time{iinput,3}=tt_relrelease(end);%output for the relative release  time
                final_Frame{iinput,4}=green(1,7); %corresponding AoI number
                final_Time{iinput,4}=green(1,7); %corresponding AoI number
                final_Frame{iinput,5}=d_g(end);%output for the corresponding Frame Interval for green
                final_Frame{iinput,6}=d_r(end);%output for the corresponding Frame Interval for red
                final_Time{iinput,5}=d1_g(end);%output for the corresponding time Interval for green
                final_Time{iinput,6}=d1_r(end);%output for the corresponding time Interval for red
                
                
                iinput=iinput+1;
                iout=iinput;
                %%     %% %%  %% % the info output of C type of event
                
                C1(c1_c,1)=green(i,7);
                C1(c1_c,2)=tt_relstart(end);
                C1(c1_c,3)=tt_overlap(end);
                C1(c1_c,4)=tt_relrelease(end);
                
                C1(c1_c,5)=d1_g(end);
                C1(c1_c,6)=d1_r(end);
                c1_c=c1_c+1;
                %% 
                
            end
            
        end
    end
end

%% If events are not A, B, C, D  then it will test for the difference of the start frames of the red and green intervals, if it is smaller than the userinput number , the event will be classified as Flag(F type)
for i=1:size(green,1)
    
    
    for j=1:size(red,1)
        if(point(i)==0 && point1(j)==0)
            if(abs((red(j,2)-green(i,2)))<userinput)
                event1=[event1;'F'];
                numberF=numberF+1;
            end
        end
    end
end

%% 





final_decision{1,1}=event1;
final_decision{2,1}=event1;
final_decision{1,2}=t_relstart;
final_decision{2,2}=tt_relstart;
final_decision{1,3}=t_overlap;
final_decision{2,3}=tt_overlap;
final_decision{1,4}=t_relrelease;
final_decision{2,4}=tt_relrelease;
final_decision{1,5}=green(1,7);
final_decision{2,5}=green(1,7);
final_decision{1,6}=d_g;
final_decision{1,7}=d_r;
final_decision{2,6}=d1_g;
final_decision{2,7}=d1_r;

