function varargout = Simultaneous_Arrival(varargin)
%11/16/2017  Fatemehsadat Jamalidinan  created
%SIMULTANEOUS_ARRIVAL MATLAB code file for Simultaneous_Arrival.fig
%      SIMULTANEOUS_ARRIVAL, by itself, creates a new SIMULTANEOUS_ARRIVAL or raises the existing
%      singleton*.
%
%      H = SIMULTANEOUS_ARRIVAL returns the handle to a new SIMULTANEOUS_ARRIVAL or the handle to
%      the existing singleton*.
%
%      SIMULTANEOUS_ARRIVAL('Property','Value',...) creates a new SIMULTANEOUS_ARRIVAL using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to Simultaneous_Arrival_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      SIMULTANEOUS_ARRIVAL('CALLBACK') and SIMULTANEOUS_ARRIVAL('CALLBACK',hObject,...) call the
%      local function named CALLBACK in SIMULTANEOUS_ARRIVAL.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Simultaneous_Arrival

% Last Modified by GUIDE v2.5 29-Nov-2017 12:39:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Simultaneous_Arrival_OpeningFcn, ...
                   'gui_OutputFcn',  @Simultaneous_Arrival_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end
try
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
catch
    Error=1;
end
% End initialization code - DO NOT EDIT


% --- Executes just before Simultaneous_Arrival is made visible.
function Simultaneous_Arrival_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)
imshow('bg_header.png')
% Choose default command line output for Simultaneous_Arrival
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
  set(handles.deltatime, 'enable','off')
  set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')


set(handles.Time, 'Value',0)
set(handles.Frame, 'Value',0)
set(handles.MThree, 'Value',0)
set(handles.One, 'Value',0)
set(handles.three, 'Value',0)

set(handles.deltaframe,'String','')
set(handles.framelimit,'String','')
set(handles.deltatime,'String','')
set(handles.timelimit,'String','')
set(handles.Out_dir,'String','');
set(handles.red_dir,'String','');
set(handles.Green_dir,'String','');

% UIWAIT makes Simultaneous_Arrival wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Simultaneous_Arrival_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Time.
function Time_Callback(hObject, eventdata, handles)
% hObject    handle to Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.Time, 'Value')==1)
set(handles.timelimit, 'enable','on')
  set(handles.text3, 'enable','on')
  set(handles.text5, 'enable','on')
  set(handles.deltatime, 'enable','on')
else
    set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
  set(handles.deltatime, 'enable','off')
end

if(get(handles.Frame, 'Value')==0)
  set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')
else
      set(handles.framelimit, 'enable','on')
  set(handles.text2, 'enable','on')
  set(handles.text6, 'enable','on')
set(handles.deltaframe, 'enable','on')
end
    
% Hint: get(hObject,'Value') returns toggle state of Time


% --- Executes on button press in three.
function three_Callback(hObject, eventdata, handles)
% hObject    handle to three (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of three


% --- Executes on button press in Input_green.
function Input_green_Callback(hObject, eventdata, handles)
% hObject    handle to Input_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green a_red b_red OUTPUT_DIR;

% hObject    handle to In_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
[fn, fp]=uigetfile('*.mat', 'Select the 1st Interval .mat File to Analyze', 'Multiselect', 'off');
% fp_baseout = uigetdir(fp, 'Select a folder to write images and step counts to:');


eval(['load ' [fp fn] ' -mat']);

a_green=Intervals.CumulativeIntervalArray;
b_green=Intervals.AllTracesCellArray;
set(handles.Out_dir,'String','');
set(handles.Green_dir,'String',[fp fn]);
catch
   msgbox('The machine can not read the interval .mat file you wish to analyze');
   set(handles.Green_dir,'String','');
end


function framelimit_Callback(hObject, eventdata, handles)
% hObject    handle to framelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of framelimit as text
%        str2double(get(hObject,'String')) returns contents of framelimit as a double


% --- Executes during object creation, after setting all properties.
function framelimit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to framelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in analyze.
function analyze_Callback(hObject, eventdata, handles)
% hObject    handle to analyze (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green a_red b_red OUTPUT_DIR;
set(handles.busy,'String','busy')
one_pointer=0;
mtherr_pointer=0;
three_pointer=0;
if(get(handles.MThree, 'Value')==1)
mtherr_pointer=1;
end
if(get(handles.One, 'Value')==1)
one_pointer=1;
end
if(get(handles.three, 'Value')==1)
three_pointer=1;
end
if((three_pointer||one_pointer||mtherr_pointer)==0)
    msgbox('Select at least one type of event(-3,1,3)')
end
a{:,1}=a_green;
a{:,2}=a_red;
b{:,1}=b_green;
b{:,2}=b_red;
AOI_max=0;
for k=1:2
    AOI_max=max(max(AOI_max,a{:,k}(:,7)));
end
%%%finding the information of the  corresponding AOI 's for both colors and
%%% saving them in out array
for i=1:AOI_max 
    for k=1:2
        f{i,k}=find(a{:,k}(:,7)==i);
    end
end
cvb=[];

j=1;

for i=1:AOI_max
    tt=1;
    for k=1:2
        if(isempty(f{i,k}))
            tt=0;
        end
        
    end
    if(tt==1)
        cvb=[cvb; i];
    end
end

for i=1:length(cvb)
    out{i,1}=a{1,1}([f{cvb(i),1}]',:);
    out{i,2}=a{1,2}([f{cvb(i),2}]',:);
end
clear cvb f g k j i Intervals tt AOI_max a
%% finding the high values base the user request
if(one_pointer && mtherr_pointer && three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==1));(find(out{i,1}(:,1)==3))];
    cb=[(find(out{i,2}(:,1)==-3));(find(out{i,2}(:,1)==1));(find(out{i,2}(:,1)==3))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(one_pointer && mtherr_pointer) 
   i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==1))];
    cb=[(find(out{i,2}(:,1)==-3));(find(out{i,2}(:,1)==1))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end   
elseif(one_pointer && three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==1));(find(out{i,1}(:,1)==3))];
    cb=[(find(out{i,2}(:,1)==1));(find(out{i,2}(:,1)==3))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(mtherr_pointer && three_pointer)
    i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3));(find(out{i,1}(:,1)==3))];
    cb=[(find(out{i,2}(:,1)==-3));(find(out{i,2}(:,1)==3))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end
elseif(mtherr_pointer)
  i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==-3))];
    cb=[(find(out{i,2}(:,1)==-3))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end

elseif(one_pointer )
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==1))];
    cb=[(find(out{i,2}(:,1)==1))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end

elseif(three_pointer)
i1=1;
for i=1:size(out,1)
    vb=[(find(out{i,1}(:,1)==3))];
    cb=[(find(out{i,2}(:,1)==3))];
    out1{i1,1}=out{i,1}((vb),:);
    out1{i1,2}=out{i,2}(cb,:);
    if(size(out1{i1,1},1)==0 ||size(out1{i1,2},1)==0)
        i1=i1-1;
    end
    i1=i1+1;
end

end

if( (length(out1{1,1})&& length(out1{1,2}))==0)
    msgbox('The machine couldnot find the matching event')
end

if(get(handles.Frame, 'Value')==1)
framelimit=str2num(get(handles.framelimit,'String'));
delta_f=str2num(get(handles.deltaframe,'String'));
%% Initial value
A=0;
AB=0;
S=0;
B=0;

na=0;
nb=0;
nc=0;
nf=0;
nd=0;
Frame=[];
bn=1;
iinput=0;
iout=0;
ii=1;
A_info=[];
B_info=[];
C_info=[];
D_info=[];
%% Calling the event classification function
for i=1:size(out1,1)
       
    try
     [outt,numberA,numberB,numberC,numberF,numberD, final_Frame,final_Time,iout,A1,B1,C1,D1]=eventclassification_sim_Frame(out1{i,1},out1{i,2},b,framelimit,delta_f);
    catch
        cvb=0;
    end
   A_info=[A_info;A1];
      B_info=[B_info;B1];
      C_info=[C_info;C1];
      D_info=[D_info;D1];
     
     if(iout~=0)
         for tt=1:size(final_Frame,1)  
             for tt1=1:6
             Final_frame_matrix(ii,tt1)=final_Frame{tt,tt1};
             Final_time_matrix(ii,tt1)=final_Time{tt,tt1};
             end
             ii=ii+1;
         end
     
     end


    Out.final_decision{i,1} = outt;
    na=na+numberA;
    nb=nb+numberB;
    nc=nc+numberC;
    nf=nf+numberF;
nd=nd+numberD;
     
end

    
%% Saving the result and plotting the bargraph for different type events
str = {'A' 'B' 'C' 'D'};
x=1:4;
y=[na nb nc nd];
h=figure;
bar(x,y);
set(gca, 'XTickLabel',str, 'XTick',1:numel(str))
ylabel('Number of Events')

saveas(h,[OUTPUT_DIR '/out_Frame.fig']);
Out.Description{1,1}=('(events type)(relative start frame)(Frame_overlap)(relative release frame)(#AoI)(delta Frame_green)(delta Frame_red) ');
Out.Description{2,1}=('(events type)(relative start time)(Time_overlap)(relative release time)(#AoI)(delta Time_green)(delta Time_red)'); 
Out.num_A=na;
Out.num_B=nb;
Out.num_C=nc;
Out.num_F=nf;
Out.num_D=nd;
info_Description{1,1}=('(1_AOI)(2_relative start time:(red_start-green_start))(3_Time_overlap)(4_relative release time:(red_end-green_end))(5_delta time_green)(6_delta time_red) ');

clear tt S out i fp_baseout fp folder fn filenames x Time_St_Rl Time y numberme filenameArray B  AB A outt numberA numberB numberAB numbers nb na ns nab  j nme str
clear tt1 time_stvsrl k iout iinput ii Frame final_Time final_Frame event bn
clear S1 M1 B1 A1 C1 D1  numberC numberD numberF nf nd nc i1 hjk framelimit delta_t cvb cb vb 
save([OUTPUT_DIR '/result_frame.mat'],'Out','info_Description','Final_time_matrix','Final_frame_matrix','D_info','C_info','B_info','A_info');
clear Out Final_frame_matrix Final_time_matrix B_info A_info C_info D_info Final_frame_matrix Final_time_matrix info_Description Out
end

if(get(handles.Time, 'Value')==1)
timelimit=str2num(get(handles.timelimit,'String'));
delta_t=str2num(get(handles.deltatime,'String'));
%% Initial value
A=0;
AB=0;
S=0;
B=0;

na=0;
nb=0;
nc=0;
nf=0;
nd=0;
Frame=[];
bn=1;
iinput=0;
iout=0;
ii=1;
A_info=[];
B_info=[];
C_info=[];
D_info=[];
%% Calling the event classification function
for i=1:size(out1,1)
       
    try
     [outt,numberA,numberB,numberC,numberF,numberD, final_Frame,final_Time,iout,A1,B1,C1,D1]=eventclassification_sim_Time(out1{i,1},out1{i,2},b,timelimit,delta_t);
    catch
        cvb=0;
    end
   A_info=[A_info;A1];
      B_info=[B_info;B1];
      C_info=[C_info;C1];
      D_info=[D_info;D1];
     
     if(iout~=0)
         for tt=1:size(final_Frame,1)  
             for tt1=1:6
             Final_frame_matrix(ii,tt1)=final_Frame{tt,tt1};
             Final_time_matrix(ii,tt1)=final_Time{tt,tt1};
             end
             ii=ii+1;
         end
     
     end


    Out.final_decision{i,1} = outt;
    na=na+numberA;
    nb=nb+numberB;
    nc=nc+numberC;
    nf=nf+numberF;
nd=nd+numberD;
     
end

    
%% Saving the result and plotting the bargraph for different type events
str = {'A' 'B' 'C' 'D'};
x=1:4;
y=[na nb nc nd];
h=figure;
bar(x,y);
set(gca, 'XTickLabel',str, 'XTick',1:numel(str))
ylabel('Number of Events')

saveas(h,[OUTPUT_DIR '/out_Time.fig']);
Out.Description{1,1}=('(events type)(relative start frame)(Frame_overlap)(relative release frame)(#AoI)(delta Frame_green)(delta Frame_red) ');
Out.Description{2,1}=('(events type)(relative start time)(Time_overlap)(relative release time)(#AoI)(delta Time_green)(delta Time_red)'); 
Out.num_A=na;
Out.num_B=nb;
Out.num_C=nc;
Out.num_F=nf;
Out.num_D=nd;
info_Description{1,1}=('(1_AOI)(2_relative start time:(red_start-green_start))(3_Time_overlap)(4_relative release time:(red_end-green_end))(5_delta time_green)(6_delta time_red) ');

clear tt S out i fp_baseout fp folder fn filenames x Time_St_Rl Time y numberme filenameArray B  AB A outt numberA numberB numberAB numbers nb na ns nab  j nme str
clear tt1 time_stvsrl k iout iinput ii Frame final_Time final_Frame event bn
clear S1 M1 B1 A1 C1 D1  numberC numberD numberF nf nd nc i1 hjk framelimit delta_t cvb cb vb 
save([OUTPUT_DIR '/result_time.mat'],'Out','info_Description','Final_time_matrix','Final_frame_matrix','D_info','C_info','B_info','A_info');
clear Out Final_frame_matrix Final_time_matrix B_info A_info C_info D_info Final_frame_matrix Final_time_matrix info_Description Out
end
set(handles.busy,'String','')






% --- Executes on button press in Frame.
function Frame_Callback(hObject, eventdata, handles)
% hObject    handle to Frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.Frame, 'Value')==1)
  set(handles.framelimit, 'enable','on')
  set(handles.text2, 'enable','on')
  set(handles.text6, 'enable','on')
set(handles.deltaframe, 'enable','on')
else
    set(handles.framelimit, 'enable','off')
  set(handles.text2, 'enable','off')
  set(handles.text6, 'enable','off')
set(handles.deltaframe, 'enable','off')
end

if(get(handles.Time, 'Value')==0)
set(handles.timelimit, 'enable','off')
  set(handles.text3, 'enable','off')
  set(handles.text5, 'enable','off')
set(handles.deltatime, 'enable','off')
else
    set(handles.timelimit, 'enable','on')
  set(handles.text3, 'enable','on')
  set(handles.text5, 'enable','on')
set(handles.deltatime, 'enable','on')
end
% Hint: get(hObject,'Value') returns toggle state of Frame



function timelimit_Callback(hObject, eventdata, handles)
% hObject    handle to timelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timelimit as text
%        str2double(get(hObject,'String')) returns contents of timelimit as a double


% --- Executes during object creation, after setting all properties.
function timelimit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timelimit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function deltatime_Callback(hObject, eventdata, handles)
% hObject    handle to deltatime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of deltatime as text
%        str2double(get(hObject,'String')) returns contents of deltatime as a double


% --- Executes during object creation, after setting all properties.
function deltatime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deltatime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in output.
function output_Callback(hObject, eventdata, handles)
% hObject    handle to output (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a_green b_green a_red b_red OUTPUT_DIR;
 OUTPUT_DIR = uigetdir('Select a folder to write images and results to:');
   set(handles.Out_dir,'String',OUTPUT_DIR); 
    if(OUTPUT_DIR==0)
        set(handles.Out_dir,'String',''); 
    end
  


function red_dir_Callback(hObject, eventdata, handles)
% hObject    handle to red_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of red_dir as text
%        str2double(get(hObject,'String')) returns contents of red_dir as a double


% --- Executes during object creation, after setting all properties.
function red_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to red_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Input_red.
function Input_red_Callback(hObject, eventdata, handles)
% hObject    handle to Input_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global a_green b_green a_red b_red OUTPUT_DIR;

% hObject    handle to In_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
[fn, fp]=uigetfile('*.mat', 'Select the 1st Interval .mat File to Analyze', 'Multiselect', 'off');
% fp_baseout = uigetdir(fp, 'Select a folder to write images and step counts to:');


eval(['load ' [fp fn] ' -mat']);

a_red=Intervals.CumulativeIntervalArray;
b_red=Intervals.AllTracesCellArray;
set(handles.Out_dir,'String','');
set(handles.red_dir,'String',[fp fn]);
catch
    msgbox('The machine can not read the interval .mat file you wish to analyze');
    set(handles.red_dir,'String','');
end



% --- Executes during object creation, after setting all properties.
function Input_red_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Input_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function Green_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Green_dir as text
%        str2double(get(hObject,'String')) returns contents of Green_dir as a double


% --- Executes during object creation, after setting all properties.
function Green_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Green_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Out_dir_Callback(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Out_dir as text
%        str2double(get(hObject,'String')) returns contents of Out_dir as a double


% --- Executes during object creation, after setting all properties.
function Out_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Out_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function deltaframe_Callback(hObject, eventdata, handles)
% hObject    handle to deltaframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of deltaframe as text
%        str2double(get(hObject,'String')) returns contents of deltaframe as a double


% --- Executes during object creation, after setting all properties.
function deltaframe_CreateFcn(hObject, eventdata, handles)
% hObject    handle to deltaframe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in MThree.
function MThree_Callback(hObject, eventdata, handles)
% hObject    handle to MThree (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MThree


% --- Executes on button press in One.
function One_Callback(hObject, eventdata, handles)
% hObject    handle to One (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of One


% --- Executes on button press in usermanual.
function usermanual_Callback(hObject, eventdata, handles)
% hObject    handle to usermanual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    winopen('SimultaneousArrival.pdf');
catch
    system('open SimultaneousArrival.pdf');
end
