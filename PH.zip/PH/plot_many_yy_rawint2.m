function plot_many_yy_rawint2(file_path1,file_path2,col_num,min_frames,max_frames,aoi_num)
%UNTITLED Summary of this function goes here
%   This function plots all of the traces from an integrated AOI set
%   into one figure using the subplot function.  

%   Required inputs are:
        
        % file_path = location of integrated file
        % col_num = number of columns (this determines width of subplots)
        % min_frames = start of frames for x-axis of traces
        % max_frames = end of frames for x-axis of traces
        % y_scale = height of y-axis relative to minimum y-axis value (this
        %           sets each plot to the same scale)
        % aoi_num = number of aois specified by user (see examples below) 

%   An example:
%   plot_all_rawint('C:\matlab\data\4-5-1_wt_INT_022210.dat',12,1,3000,3000,150);
%      with 12 columns, frames 1 to 3000
%      with a y-axis scale of y_min + 3000
%      plots out as if there 150 aois to compare to another data set that
%      has 150 aois (this keeps the plot sizes the same)
%
%   Alternatively:
%   plot_all_rawint('C:\matlab\data\4-5-1_wt_INT_022210.dat',12,1,3000,3000,0);
%      with 12 columns, frames 1 to 3000
%      with a y-axis scale of y_min + 3000
%      plots out using the number of aois in the set 
        
    loaded1=load(file_path1,'-mat');
    
    loaded2=load(file_path2,'-mat');
    
    aoi_data1=loaded1.aoifits.data;
    
    aoi_data2=loaded2.aoifits.data;
    
    aoi_num_max=length(aoi_num);    
    
    row_num=ceil(aoi_num_max/col_num); % determine number of rows
    %row_num=3;
    %figure;
    figure('Position',[50 50 800 600],'Color',[1 1 1]);

    for aoi_count=1:aoi_num_max % loop for each AOI
    
        aoi_num1=aoi_data1(:,1)==aoi_num(aoi_count);
        frames1=aoi_data1(aoi_num1,2);
        raw_int_aoi1=aoi_data1(aoi_num1,8);
        int_aoi1=raw_int_aoi1-min(raw_int_aoi1);
        int_aoi1n=int_aoi1/max(int_aoi1);
        int_aoi1n=int_aoi1n+0.5;
        
        aoi_num2=aoi_data2(:,1)==aoi_num(aoi_count);
        frames2=aoi_data2(aoi_num2,2);
        raw_int_aoi2=aoi_data2(aoi_num2,8);
        int_aoi2=raw_int_aoi2-min(raw_int_aoi2);
        int_aoi2(int_aoi2>1e5)=1e5;
        int_aoi2n=int_aoi2/max(int_aoi2);
        
            
        subplot(row_num,col_num,aoi_count);  % specifies which subplot
      
        [AX, H1, H2] = plotyy(frames1,int_aoi1n,frames2,int_aoi2n,'plot');
        
%        [AX, H1, H2] = plotyy(frames1(min_frames:max_frames),int_aoi1(min_frames:max_frames),...
 %           frames2(min_frames:max_frames),int_aoi2(min_frames:max_frames),'plot');
        
        %y_min1=min(int_aoi1(min_frames:max_frames));
        %y_min1=min(int_aoi1)+1000;
        %y_max1=y_min1+y_scale1;
        %y_max1=max(int_aoi1);
        %if y_max1>14000;
         %  y_max1=5000;
        %end
        
        %y_min2=min(int_aoi2(min_frames:max_frames));
        %y_min2=min(int_aoi2)+1000;
       % y_max2=y_min2+y_scale2;
        %y_max2=max(int_aoi2);
        %if y_max2>30000;
         %  y_max2=15000;
        %end
        
        %ylim(AX(1),[(y_min1-y_scale1) y_max1]);
        ylim(AX(1),[0 1.5]);
        ylim(AX(2),[0 1.5]);
        %ylim(AX(2),[(y_min2-y_scale2/1.2) y_max2]);
        
        xlim(AX(1),[min_frames max_frames]);
        xlim(AX(2),[min_frames max_frames]);
        
        %set(AX(1),'xtick',[],'ytick',[]);
        %set(AX(2),'xtick',[],'ytick',[]);
        
        set(H2,'color',[0.91765,0.13333,0.16471],'LineWidth', 1.5); %DJC red
        set(H1,'color',[0.41176,0.74118,0.27059],'LineWidth', 1.5); %DJC green
        
       % set(H1,'color',[0,0.44,0.69]); %blue
       % set(H2,'color',[1,0.32,0]); %orange
        
      %  set(AX(1),'ytick',[], 'TickLength',[0 0]);
       % set(AX(2),'ytick',[], 'TickLength',[0 0]);
        
       if aoi_count < aoi_num_max;
            set(AX(1),'xtick',[],'ytick',[], 'TickLength',[0 0],'XColor',[1 1 1],'YColor',[1 1 1]);
            set(AX(2),'xtick',[],'ytick',[], 'TickLength',[0 0],'XColor',[1 1 1],'YColor',[1 1 1]);
            %set(AX(1),'XColor',[1 1 1],'YColor',[1 1 1]);
            %set(AX(2),'XColor',[1 1 1],'YColor',[1 1 1]);
       elseif aoi_count == aoi_num_max; 
            set(AX(1),'xtick',[],'ytick',[], 'TickLength',[0 0],'XColor',[1 1 1],'YColor',[1 1 1]);
            set(AX(2),'ytick',[], 'TickLength',[0 0],'XColor','k','YColor',[1 1 1]);
            xlabel('Frames (1 frame/sec)');
       end
        %set(AX(1),'xtick',[],'ytick',[], 'TickLength',[0 0]);
        %set(AX(2),'xtick',[],'ytick',[], 'TickLength',[0 0]);
        
               
        %text(50,y_max1-200, ['AOI# ' mat2str(aoi_num(aoi_count))], 'FontSize',10);
        title(['AOI# ' mat2str(aoi_num(aoi_count))]);
        
        %set(gca,'xtick',[],'ytick',[]); % important to get rid of tickmarks
        
        %axis tight % scales axes to fit trace
    end
  
end

