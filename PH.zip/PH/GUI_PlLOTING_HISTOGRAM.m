function varargout = GUI_PlLOTING_HISTOGRAM(varargin)
% Fatemehsadat Jamalidinan  created
% GUI_PILOTING_HISTOGRAM MATLAB code for GUI_PILOTING_HISTOGRAM.fig
%      GUI_PILOTING_HISTOGRAM, by itself, creates a new GUI_PILOTING_HISTOGRAM or raises the existing
%      singleton*.
%
%      H = GUI_PILOTING_HISTOGRAM returns the handle to a new GUI_PILOTING_HISTOGRAM or the handle to
%      the existing singleton*.
%
%      GUI_PILOTING_HISTOGRAM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_PLLOTING_HISTOGRAM.M with the given input arguments.
%
%      GUI_PLLOTING_HISTOGRAM('Property','Value',...) creates a new GUI_PLLOTING_HISTOGRAM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_PlLOTING_HISTOGRAM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_PlLOTING_HISTOGRAM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_PlLOTING_HISTOGRAM

% Last Modified by GUIDE v2.5 29-Nov-2017 12:39:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @GUI_PlLOTING_HISTOGRAM_OpeningFcn, ...
    'gui_OutputFcn',  @GUI_PlLOTING_HISTOGRAM_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    try
        gui_mainfcn(gui_State, varargin{:});
    catch
        vb=0;
        
    end
end

% End initialization code - DO NOT EDIT

% --- Executes just before GUI_PlLOTING_HISTOGRAM is made visible.
function GUI_PlLOTING_HISTOGRAM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_PlLOTING_HISTOGRAM (see VARARGIN)

% Choose default command line output for GUI_PlLOTING_HISTOGRAM


imshow('1.png')
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
if isfield(handles, 'metricdata') && ~isreset
    return;
end
% This sets up the initial plot - only do when we are invisible
% so window can get raised using GUI_PlLOTING_HISTOGRAM.
% if strcmp(get(hObject,'Visible'),'off')
%     plot(rand(5));
% end
% set(handles.unitgroup, 'SelectedObject', handles.time);
% UIWAIT makes GUI_PlLOTING_HISTOGRAM wait for user response (see UIRESUME)
% uiwait(handles.figure1);
set(handles.ap, 'enable', 'off')
set(handles.ap1, 'enable', 'off')
set(handles.ap2, 'enable', 'off')

set(handles.tau, 'enable', 'off')
set(handles.tau1, 'enable', 'off')
set(handles.tau2, 'enable', 'off')
set(handles.tau3, 'enable', 'off')
set(handles.tx, 'enable', 'off')
set(handles.tm, 'enable', 'off')
set(handles.nboot, 'enable', 'off')

set(handles.bts_mean_tau,'String','---')
set(handles.bts_std_tau,'String','---')
set(handles.bts_mean_tau1,'String','---')
set(handles.bts_std_tau1,'String','---')
set(handles.bts_mean_tau2,'String','---')
set(handles.bts_std_tau2,'String','---')
set(handles.bts_mean_tau3,'String','---')
set(handles.bts_std_tau3,'String','---')
set(handles.bts_mean_ap,'String','---')
set(handles.bts_std_ap,'String','---')
set(handles.bts_mean_ap1,'String','---')
set(handles.bts_std_ap1,'String','---')
set(handles.bts_mean_ap2,'String','---')
set(handles.bts_std_ap2,'String','---')
set(handles.out_tau,'String','---')
set(handles.out_tau1,'String','---')
set(handles.out_tau2,'String','---')
set(handles.out_tau3,'String','---')
set(handles.out_ap,'String','---')
set(handles.out_ap1,'String','---')
set(handles.out_ap2,'String','---')
set(handles.Sturges, 'enable', 'on')
set(handles.fd, 'enable', 'on')
set(handles.Scott, 'enable', 'on')
set(handles.middle, 'enable', 'on')
set(handles.opt, 'enable','on')
set(handles.all, 'enable','on')

% --- Outputs from this function are returned to the command line.
function varargout = GUI_PlLOTING_HISTOGRAM_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% axes(handles.axes1);Fatemeh
% cla;Fatemeh
try
    
    [fn fp]=uigetfile;
    eval(['load ' [fp fn] ' -mat']);
    fp = uigetdir(fp, 'Select a folder to write images and results to:');
    out=[fp '/' fn '_out'];
    cia=Intervals.CumulativeIntervalArray;
    set(handles.busy,'String','busy')
    popup_sel_index = get(handles.popupmenu1, 'Value');
    Chk_sel_index = get(handles.Time, 'Value');
    Chk_sel_index1 = get(handles.Frame, 'Value');
    popup_sel_index3 = get(handles.popupmenu3, 'Value');
    Chk_sel_index_fd = get(handles.fd, 'Value');
    Chk_sel_index_Scott = get(handles.Scott, 'Value');
    Chk_sel_index_Sturges = get(handles.Sturges, 'Value');
    Chk_sel_index_middle = get(handles.middle, 'Value');
    Chk_sel_index_opt = get(handles.opt, 'Value');
    Chk_sel_index_all = get(handles.all, 'Value');
    switch popup_sel_index3
        case 1
            jj='expfallone_mxl';
            
            tau=handles.metricdata.tau;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg=tau;
        case 2
            jj= 'expfallone_all_events_mxl';
            %         x=inputdlg('Enter exponential time constant(tau)','tau',[1]);
            %         tau=str2num(x{:});
            %         x=inputdlg('Enter minimum interval length that can be resolved in the experiment(tm)','TM',[1]);
            %         tm=str2num(x{:});
            %         x=inputdlg('Enter Vector list of intervals for spots that do NOT vanish( mxintervals)',' mxintervals',[1]);
            %         mxintervals=str2num(x{:});
            %         x=inputdlg('Enter nboot',' distribution (of size nboot)',[1]);
            %         nboot=str2num(x{:});
            %         inarg=tau;
            %         fminsrch=['expfallone_all_events_mxl',tau,[],EventLengths,mxintervals,tm];
            %         bootstrp=[nboot,inarg,EventLengths,mxintervals,tm];
            %         bootstrapc=2;
            
            tau=handles.metricdata.tau;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg=tau;
        case 3
            
            jj= 'Expfalltwo_mxl';
            %         x=inputdlg('Enter inarg = [ ap tau1 tau2]','inarg',[1 4]);
            
            ap=handles.metricdata.ap;
            tau1=handles.metricdata.tau1;
            tau2=handles.metricdata.tau2;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg = [ ap tau1 tau2];
            
        case 4
            jj='expfalltwo_all_events_mxl';
            %         x=inputdlg('Enter inarg = [ ap tau1 tau2]','inarg',[1 4]);
            %         inarg=str2num(x{:});
            %         x=inputdlg('Enter Vector list of intervals for spots that do NOT vanish( mxintervals)',' mxintervals',[1]);
            %         mxintervals=str2num(x{:});
            %         x=inputdlg('Enter maximum interval length that can be resolved in the experiment(tx)','TX',[1]);
            %         tx=str2num(x{:});
            %         x=inputdlg('Enter nboot',' distribution (of size nboot)',[1]);
            %         nboot=str2num(x{:});
            %         fminsrch=['expfallone_all_events_mxl',inarg,[],EventLengths,mxintervals,tm];
            %         bootstrp=[nboot,inarg,EventLengths,mxintervals,tm];
            %         bootstrapc=4;
            
            ap=handles.metricdata.ap;
            tau1=handles.metricdata.tau1;
            tau2=handles.metricdata.tau2;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg = [ ap tau1 tau2];
        case 5
            jj='expfallthree_mxl';
            %         x=inputdlg('Enter inarg = [ ap1 ap2 tau1 tau2 tau3 ]','inarg',[1 6]);
            %         inarg=str2num(x{:});
            %         x=inputdlg('Enter minimum interval length that can be resolved in the experiment(tm)','TM',[1]);
            %         tm=str2num(x{:});
            %         x=inputdlg('Enter maximum interval length that can be resolved in the experiment(tx)','TX',[1]);
            %         tx=str2num(x{:});
            %         x=inputdlg('Enter nboot',' distribution (of size nboot)',[1]);
            %         nboot=str2num(x{:});
            
            ap2=handles.metricdata.ap2;
            ap1=handles.metricdata.ap1;
            tau1=handles.metricdata.tau1;
            tau2=handles.metricdata.tau2;
            tau3=handles.metricdata.tau3;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
        case 6
            jj='expfalthree_all_events_mxl';
            %         x=inputdlg('Enter inarg = [ ap1 ap2 tau1 tau2 tau3 ]','inarg',[1 6]);
            %         inarg=str2num(x{:});
            %         x=inputdlg('Enter Vector list of intervals for spots that do NOT vanish( mxintervals)',' mxintervals',[1]);
            %         mxintervals=str2num(x{:});
            %         x=inputdlg('Enter maximum interval length that can be resolved in the experiment(tx)','TX',[1]);
            %         tx=str2num(x{:});
            %         x=inputdlg('Enter nboot',' distribution (of size nboot)',[1]);
            %         nboot=str2num(x{:});
            % %         fminsrch=['expfallone_all_events_mxl',inarg,[],EventLengths,mxintervals,tm];
            %         bootstrp=[nboot,inarg,EventLengths,mxintervals,tm];
            %         bootstrapc=6;
            
            ap2=handles.metricdata.ap2;
            ap1=handles.metricdata.ap1;
            tau1=handles.metricdata.tau1;
            tau2=handles.metricdata.tau2;
            tau3=handles.metricdata.tau3;
            tm=handles.metricdata.tm;
            tx=handles.metricdata.tx;
            nboot=handles.metricdata.nboot;
            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
    end
    
    popup_sel_index = get(handles.popupmenu1, 'Value');
    
    %
    %            mn1=0;
    %
    %         end
    % switch popup_sel_index  Fatemeh
    switch popup_sel_index
        case 1
            N=-3;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3';
            
        case 2
            N=-2;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2';
        case 3
            N=0;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0';
        case 4
            N=1;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='1';
        case 5
            N=2;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='2';
        case 6
            N=3;
            N1=-1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='3';
            
        case 7
            N=-3;
            N1=-2;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3';
        case 8
            N=-3;
            N1=0;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_0';
        case 9
            N=-3;
            N1=1;
            
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_1';
        case 10
            N=-3;
            N1=2;
            
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_2';
            
        case 11
            N=-3;
            N1=3;
            N1=0;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_3_0';
        case 12
            N=-2;
            N1=0;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_0';
        case 13
            N=-2;
            N1=1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_1';
        case 14
            N=-2;
            N1=3;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_3';
        case 15
            N=0;
            N1=1;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0_1';
        case 16
            N=0;
            N1=2;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0_2';
        case 17
            N=0;
            N1=3;
            
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0_3';
            
        case 18
            N=1;
            N1=2;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='1_2';
        case 19
            N=1;
            N1=3;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='1_3';
        case 20
            N=2;
            N1=3;
            N2=-1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='2_3';
            %%%%%%%%%%
        case 21
            N=-3;
            N1=-2;
            N2=0;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_-2_0';
        case 22
            N=-3;
            N1=-2;
            N2=1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_-2_1';
        case 23
            N=-3;
            N1=-2;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_-2_2';
        case 24
            N=-3;
            N1=-2;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_-2_3';
        case 25
            N=-3;
            N1=0;
            N2=1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_0_1';
        case 26
            N=-3;
            N1=0;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_0_2';
            
        case 27
            N=-3;
            N1=0;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_0_3';
        case 28
            N=-3;
            N1=1;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_1_2';
            
        case 29
            N=-3;
            N1=1;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_1_3';
        case 30
            N=-3;
            N1=2;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-3_2_3';
            
            
        case 31
            N=-2;
            N1=0;
            N2=1;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_0_1';
        case 32
            N=-2;
            N1=0;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_0_2';
        case 33
            N=-2;
            N1=0;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_0_3';
        case 34
            N=-2;
            N1=1;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_1_2';
        case 35
            N=-2;
            N1=1;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='-2_1_3';
            
            
        case 36
            N=0;
            N1=1;
            N2=2;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0_1_2';
        case 37
            N=0;
            N1=1;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='0_1_3';
        case 38
            N=0;
            N1=2;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            
        case 39
            N=1;
            N1=2;
            N2=3;
            N3=-1;
            N4=-1;
            N5=-1;
            aa='1_2_3';
        case 40
            N=-3;
            N1=-2;
            N2=0;
            N3=1;
            N4=-1;
            N5=-1;
            aa='-3_-2_0_1';
        case 41
            N=-3;
            N1=-2;
            N2=0;
            N3=2;
            N4=-1;
            N5=-1;
            aa='-3_-2_0_2';
        case 42
            N=-3;
            N1=-2;
            N2=0;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-3_-2_0_3';
        case 43
            N=-3;
            N1=-2;
            N2=1;
            N3=2;
            N4=-1;
            N5=-1;
            aa='-3_-2_1_2';
        case 44
            N=-3;
            N1=-2;
            N2=1;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-3_-2_1_3';
        case 45
            N=-3;
            N1=-2;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-3_-2_2_3';
        case 46
            N=-3;
            N1=0;
            N2=1;
            N3=2;
            N4=-1;
            N5=-1;
            aa='-3_0_1_2';
        case 47
            N=-3;
            N1=0;
            N2=2;
            N3=1;
            N4=-1;
            N5=-1;
            aa='-3_0_2_1';%%%%%%%%%Fatemeh
        case 48
            N=-3;
            N1=0;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-3_0_2_3';
        case 49
            N=-3;
            N1=1;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-3_1_2_3';
            
        case 50
            N=-2;
            N1=0;
            N2=1;
            N3=2;
            N4=-1;
            N5=-1;
            aa='-2_0_1_2';
        case 51
            N=-2;
            N1=0;
            N2=1;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-2_0_1_3';
        case 52
            N=-2;
            N1=0;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-2_0_2_3';
        case 53 %% fatemeh
            N=-2;
            N1=0;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-2_0_2_3';
        case 54
            N=-2;
            N1=1;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='-2_1_2_3';
        case 55
            N=0;
            N1=1;
            N2=2;
            N3=3;
            N4=-1;
            N5=-1;
            aa='0_1_2_3';
        case 56
            N=-3;
            N1=-2;
            N2=0;
            N3=1;
            N4=2;
            N5=-1;
            aa='-3_-2_0_1_2';
        case 57
            N=-3;
            N1=-2;
            N2=0;
            N3=1;
            N4=3;
            N5=-1;
            aa='-3_-2_0_1_3';
            
        case 58
            N=-3;
            N1=-2;
            N2=0;
            N3=2;
            N4=3;
            N5=-1;
            aa='-3_-2_0_2_3';
            
            
        case 59
            N=-3;
            N1=-2;
            N2=1;
            N3=2;
            N4=3;
            N5=-1;
            aa='-3_-2_1_2_3';
            
        case 60%%fatemeh
            N=-3;
            N1=-2;
            N2=1;
            N3=2;
            N4=3;
            N5=-1;
            aa='-3_-2_1_2_3';
            
            
        case 61
            N=-2;
            N1=0;
            N2=1;
            N3=2;
            N4=3;
            N5=-1;
            aa='-2_0_1_2_3';
        case 62
            N=-3;
            N1=-2;
            N2=0;
            N3=1;
            N4=2;
            N5=3;
            aa='-3_-2_0_1_2_3';
    end
    logik=cia(:,1)==N;
    logik1=cia(:,1)==N1;
    logik2=cia(:,1)==N2;
    logik3=cia(:,1)==N3;
    logik4=cia(:,1)==N4;
    logik5=cia(:,1)==N5;
    logikt=logik|logik1|logik2|logik3|logik4|logik5;
    logikt1=logik|logik1|logik2|logik3|logik4;
    Nelement=0;
    if(N~=-1)
        Nelement=Nelement+1;
    end
    if(N1~=-1)
        Nelement=Nelement+1;
    end
    if(N2~=-1)
        Nelement=Nelement+1;
    end
    if(N3~=-1)
        Nelement=Nelement+1;
    end
    if(N4~=-1)
        Nelement=Nelement+1;
    end
    if(N5~=-1)
        Nelement=Nelement+1;
    end
    if (Chk_sel_index ==1)
        EventLengths=cia(logikt,5);
        EventLengths1=cia(logikt1,5);
        EventLengths2=cia(logik5,5);
        OUTPUT_DIR=[out '_Time_duration_' aa '_' ];
%         if ~exist(OUTPUT_DIR,'dir');
%             mkdir(OUTPUT_DIR);
%         end
        popup_sel_index2 = get(handles.popupmenu2, 'Value');
        switch popup_sel_index2
            case 1
                tt1='Time(Millisecond)';
            case 2
                tt1='Time(Second)';
            case 3
                tt1='Time(Minute)';
        end
        OUTPUT_DIR1=OUTPUT_DIR;
        if(size(EventLengths,1)~=0)
            status1 = (get(handles.auto,'Value'));
            if status1 == 1;
                
                Chk_sel_index_fd = get(handles.fd, 'Value');
                Chk_sel_index_Scott = get(handles.Scott, 'Value');
                Chk_sel_index_Sturges = get(handles.Sturges, 'Value');
                Chk_sel_index_middle = get(handles.middle, 'Value');
                Chk_sel_index_opt = get(handles.opt, 'Value');
                Chk_sel_index_all = get(handles.all, 'Value');
                if(Chk_sel_index_middle==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'middle');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_middle'];
                    tt=[tt1 ',middle method '];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                                if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;thyme=intervals;tau=tau_out;
                            pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-thyme/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2));
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.bootstrp_std_a2=1-std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            [out_x]=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))
                                   
                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))
                          
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                if(Chk_sel_index_opt==1 ||Chk_sel_index_all==1)
                    optN = sshist(EventLengths);
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Optimal'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Optimal method'];
                    
                    %             [prob,binCtrs]=histfit_normalization(EventLengths,data,'exponential',tt,OUTPUT_DIR);
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx); ;
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;thyme=intervals;tau=tau_out;
                            pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-thyme/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            
                            h=figure;
                            
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');;
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                      plot(intervals,pdfEst,'b');
                            %                     hold on
                            %                     errorbar(X,Y(:,1),E(:,1), 'xr')
                            % %                     try
                            % %                         hh=bar(binCtrs,prob,'hist');
                            % %                         zoom xon
                            % %                     catch
                            % %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            % %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            % %                         zoom xon
                            % %                     end
                            % %
                            % %                     colormap summer;
                            % %                     hold on
                            % %                     plot(binCtrs,prob);
                            %                      hold off
                            %                      xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                      saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %  set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if(Chk_sel_index_fd==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'fd');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Freedman_Diaconis'];
                    tt=[tt1 ',Freedman-Diaconis'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Freedman_Diaconis'];
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;thyme=intervals;tau=tau_out;
                            pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-thyme/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                
                
                if(Chk_sel_index_Scott==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'Scott');
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Scott'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Scott method '];
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;thyme=intervals;tau=tau_out;
                            pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-thyme/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi);
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            %
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                if(Chk_sel_index_Sturges==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'Sturges');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Sturges'];
                    tt=[tt1 ',Sturges method '];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi);
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');;
                                    
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))
                      
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
            end
            
            
            
            status11 = (get(handles.manual,'Value'));
            if (status11 == 1)
                x=inputdlg('Enter space-seprated numbers','Experimental(Interval) Length',[1 50]);
                data=str2num(x{:});
                
                optN=size(data,2)-1;
                
                OUTPUT_DIR2=OUTPUT_DIR1;
                OUTPUT_DIR2=[OUTPUT_DIR2 '_manual'];
%                 if ~exist(OUTPUT_DIR2,'dir');
%                     mkdir(OUTPUT_DIR2);
%                 end
                tt=[tt1 ',manual '];
                
                
                switch popup_sel_index3
                    case 1
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                        if(tau_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                            nn=nn+1;
                           if(mean(bts)<(2*tau_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String',num2str(tau_out))
                                set(handles.out_tau1,'String','---')
                                set(handles.out_tau2,'String','---')
                                set(handles.out_tau3,'String','---')
                                set(handles.out_ap,'String','---')
                                set(handles.out_ap1,'String','---')
                                set(handles.out_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        
                        intervals=0:0.5:tx;
                        tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        h=figure
                        hist(bts)
                        ylabel('Bootstrap Histogram');
                        [fi,xi] = ksdensity(bts);
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                        h=figure;
                        %plot(xi,fi)
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                        
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau=mean(bts);
                        Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        set(handles.bts_mean_tau1,'String','---')
                        set(handles.bts_std_tau1,'String','---')
                        set(handles.bts_mean_tau2,'String','---')
                        set(handles.bts_std_tau2,'String','---')
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String','---')
                        set(handles.bts_std_ap,'String','---')
                        set(handles.bts_mean_ap1,'String','---')
                        set(handles.bts_std_ap1,'String','---')
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String',num2str(tau_out))
                        set(handles.out_tau1,'String','---')
                        set(handles.out_tau2,'String','---')
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String','---')
                        set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        
                        
                    case 2
                        
                        
                        %                     fcn
                        %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                        %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        
                        tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                        if(tau_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                            nn=nn+1;
                           if(mean(bts)<(2*tau_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String',num2str(tau_out))
                                set(handles.out_tau1,'String','---')
                                set(handles.out_tau2,'String','---')
                                set(handles.out_tau3,'String','---')
                                set(handles.out_ap,'String','---')
                                set(handles.out_ap1,'String','---')
                                set(handles.out_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        
                        intervals=0:0.5:tx;
                        tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        h=figure
                        hist(bts)
                        ylabel('Bootstrap Histogram');
                        [fi,xi] = ksdensity(bts);
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                        h=figure;
                        %plot(xi,fi)
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                        
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau=mean(bts);
                        Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        set(handles.bts_mean_tau1,'String','---')
                        set(handles.bts_std_tau1,'String','---')
                        set(handles.bts_mean_tau2,'String','---')
                        set(handles.bts_std_tau2,'String','---')
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String','---')
                        set(handles.bts_std_ap,'String','---')
                        set(handles.bts_mean_ap1,'String','---')
                        set(handles.bts_std_ap1,'String','---')
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String',num2str(tau_out))
                        set(handles.out_tau1,'String','---')
                        set(handles.out_tau2,'String','---')
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String','---')
                        set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        
                        
                    case 3
                        inarg = [ ap tau1 tau2];
                        a=1/(1+inarg(1)^2);
                        tau1=abs(inarg(2));
                        tau2=abs(inarg(3));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                        ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                        tau1_out=fn(:,2);
                        tau2_out=fn(:,3);
                        if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        thyme=intervals;
                        a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        hold on
                        plot(intervals,pdfEst,'b');
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(a1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,2));
                        Out.bootstrp_std_tau1=std(bts(:,2));
                        Out.bootstrp_mean_tau2=mean(bts(:,3));
                        Out.bootstrp_std_tau2=std(bts(:,3));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                        Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                        
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                        
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    case 4
                        
                        %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                        %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                        inarg = [ ap tau1 tau2];
                        a=1/(1+inarg(1)^2);
                        tau1=abs(inarg(2));
                        tau2=abs(inarg(3));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                        ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                        tau1_out=out_x(2);
                        tau2_out=out_x(3);
                        if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        intervals=0:0.5:tx;
                        thyme=intervals;
                        a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(a1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,2));
                        Out.bootstrp_std_tau1=std(bts(:,2));
                        Out.bootstrp_mean_tau2=mean(bts(:,3));
                        Out.bootstrp_std_tau2=std(bts(:,3));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                        Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                        
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                        
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                    case 5
                        
                        %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                        %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                        inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                        a1=1/(1+inarg(1)^2);
                        a2=(1-a1)/(1+inarg(2)^2);
                        tau1=abs(inarg(3));
                        tau2=abs(inarg(4));
                        tau3=abs(inarg(5));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                        ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                        ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                        tau1_out=mn(3);
                        tau2_out=mn(4);
                        tau3_out=mn(5);
                        if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                kkk=1;
                            end
                            if(nn>3)
                                
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String','---')
                                set(handles.out_tau1,'String',num2str(tau1_out))
                                set(handles.out_tau2,'String',num2str(tau2_out))
                                set(handles.out_tau3,'String',num2str(tau3_out))

                                set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                            ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(ap1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(ap1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(a2)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                        
                        
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,4))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,4));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,5))
                        ylabel('Bootstrap Histogram(tau3)');
                        [fi,xi] = ksdensity(bts(:,5));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                        
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,3));
                        Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                        Out.bootstrp_mean_tau2=mean(bts(:,4));
                        Out.bootstrp_std_tau2=std(bts(:,4));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                        Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                        Out.bootstrp_mean_a2=mean(bts(:,2));
                        Out.bootstrp_std_a2=std(bts(:,2));
                        Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                        Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                        set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                        set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String',num2str(tau3_out))

                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                    case 6
                        
                        %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                        inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                        a1=1/(1+inarg(1)^2);
                        a2=(1-a1)/(1+inarg(2)^2);
                        tau1=abs(inarg(3));
                        tau2=abs(inarg(4));
                        tau3=abs(inarg(5));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                        ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                        ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                        tau1_out=mn(3);
                        tau2_out=mn(4);
                        tau3_out=mn(5);
                        if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                kkk=1;
                            end
                            if(nn>3)
                                
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String','---')
                                set(handles.out_tau1,'String',num2str(tau1_out))
                                set(handles.out_tau2,'String',num2str(tau2_out))
                                set(handles.out_tau3,'String',num2str(tau3_out))
 
                                set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                            ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(ap1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(ap1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(a2)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                        
                        
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,4))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,4));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,5))
                        ylabel('Bootstrap Histogram(tau3)');
                        [fi,xi] = ksdensity(bts(:,5));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                        
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,3));
                        Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                        Out.bootstrp_mean_tau2=mean(bts(:,4));
                        Out.bootstrp_std_tau2=std(bts(:,4));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                        Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                        Out.bootstrp_mean_a2=mean(bts(:,2));
                        Out.bootstrp_std_a2=std(bts(:,2));
                        Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                        Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                        set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                        set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String',num2str(tau3_out))

                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        
                end
                %         close all
                
                
                
            end
            
            
            
            
            
            % figure;
            % %histfit_normalization(EventLengths,data,'exponential');
            % pdfplot(EventLengths);
            % colormap summer;
            % Add a legend
        else
            %      creates a message dialog box that automatically wraps Message to fit an appropriately sized figure.
            Message=['No member equal to ' num2str(N)];
            h = msgbox(Message)
        end
    end
    
    
    if (Chk_sel_index1 ==1)
        
        
        OUTPUT_DIR=[out '_Frame_duration_' ];
      %  if ~exist(OUTPUT_DIR,'dir'); mkdir(OUTPUT_DIR); end
        
        tt1='Frame';
        
        EventLengths=cia(logikt,4);
        EventLengths1=cia(logikt1,4);
        EventLengths2=cia(logik5,4);
        
        
        OUTPUT_DIR1=OUTPUT_DIR;
        if(size(EventLengths,1)~=0)
            status1 = (get(handles.auto,'Value'));
            if status1 == 1;
                
                Chk_sel_index_fd = get(handles.fd, 'Value');
                Chk_sel_index_Scott = get(handles.Scott, 'Value');
                Chk_sel_index_Sturges = get(handles.Sturges, 'Value');
                Chk_sel_index_middle = get(handles.middle, 'Value');
                Chk_sel_index_opt = get(handles.opt, 'Value');
                Chk_sel_index_all = get(handles.all, 'Value');
                if(Chk_sel_index_middle==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'middle');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_middle'];
                    tt=[tt1 ',middle method '];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                if(Chk_sel_index_opt==1 ||Chk_sel_index_all==1)
                    optN = sshist(EventLengths);
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Optimal'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Optimal method'];
                    
                    %             [prob,binCtrs]=histfit_normalization(EventLengths,data,'exponential',tt,OUTPUT_DIR);
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau,EventLengths1,EventLengths2,tm)
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if(Chk_sel_index_fd==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'fd');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Freedman_Diaconis'];
                    tt=[tt1 ',Freedman-Diaconis'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Freedman_Diaconis'];
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))
            
                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                
                
                if(Chk_sel_index_Scott==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'Scott');
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Scott'];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    tt=[tt1 ',Scott method '];
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %  set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            %set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))
                          
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
                
                if(Chk_sel_index_Sturges==1 ||Chk_sel_index_all==1)
                    optN = calcnbins(EventLengths,'Sturges');
                    data=0:(tx)/optN:tx;
                    OUTPUT_DIR2=OUTPUT_DIR1;
                    OUTPUT_DIR2=[OUTPUT_DIR2 '_Auto_Sturges'];
                    tt=[tt1 ',Sturges method '];
%                     if ~exist(OUTPUT_DIR2,'dir');
%                         mkdir(OUTPUT_DIR2);
%                     end
                    
                    switch popup_sel_index3
                        case 1
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 2
                            
                            
                            %                     fcn
                            %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                            %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            
                            tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                            if(tau_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                                nn=nn+1;
                               if(mean(bts)<(2*tau_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String',num2str(tau_out))
                                    set(handles.out_tau1,'String','---')
                                    set(handles.out_tau2,'String','---')
                                    set(handles.out_tau3,'String','---')
                                    set(handles.out_ap,'String','---')
                                    set(handles.out_ap1,'String','---')
                                    set(handles.out_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            
                            %                     bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                            intervals=0:0.5:tx;
                            tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            h=figure
                            hist(bts)
                            ylabel('Bootstrap Histogram');
                            [fi,xi] = ksdensity(bts);
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                            h=figure;
                            %plot(xi,fi)
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                            
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau=mean(bts);
                            Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                            set(handles.bts_std_tau,'String',num2str(std(bts)))
                            set(handles.bts_mean_tau1,'String','---')
                            set(handles.bts_std_tau1,'String','---')
                            set(handles.bts_mean_tau2,'String','---')
                            set(handles.bts_std_tau2,'String','---')
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String','---')
                            set(handles.bts_std_ap,'String','---')
                            set(handles.bts_mean_ap1,'String','---')
                            set(handles.bts_std_ap1,'String','---')
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String',num2str(tau_out))
                            set(handles.out_tau1,'String','---')
                            set(handles.out_tau2,'String','---')
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String','---')
                            set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            
                            
                        case 3
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                            ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=fn(:,2);
                            tau2_out=fn(:,3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            hold on
                            plot(intervals,pdfEst,'b');
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                        case 4
                            
                            %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                            inarg = [ ap tau1 tau2];
                            a=1/(1+inarg(1)^2);
                            tau1=abs(inarg(2));
                            tau2=abs(inarg(3));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                            tau1_out=out_x(2);
                            tau2_out=out_x(3);
                            if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            intervals=0:0.5:tx;
                            thyme=intervals;
                            a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                            
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,2));
                            Out.bootstrp_std_tau1=std(bts(:,2));
                            Out.bootstrp_mean_tau2=mean(bts(:,3));
                            Out.bootstrp_std_tau2=std(bts(:,3));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                            Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                            
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau3,'String','---')
                            set(handles.bts_std_tau3,'String','---')
                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                            
                            set(handles.bts_mean_ap2,'String','---')
                            set(handles.bts_std_ap2,'String','---')
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String','---')
                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                            % set(handles.out_ap1,'String','---')
                            set(handles.out_ap2,'String','---')
                        case 5
                            
                            %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            hold off
                            %                     hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        case 6
                            
                            %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                            inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                            a1=1/(1+inarg(1)^2);
                            a2=(1-a1)/(1+inarg(2)^2);
                            tau1=abs(inarg(3));
                            tau2=abs(inarg(4));
                            tau3=abs(inarg(5));
                            
                            %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                            %                     m= bootstrp(100,@mean,prob);
                            
                            OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                            if ~exist(OUTPUT_DIR,'dir');
                                mkdir(OUTPUT_DIR);
                            end
                            [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                            binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                            if(length(EventLengths2)==0)
                               msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                                return
                            end
                            mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                            ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                            ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                            tau1_out=mn(3);
                            tau2_out=mn(4);
                            tau3_out=mn(5);
                            if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                               msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                                return
                            end
                            kkk=0;
                            nn=0;
                            while(kkk==0)
                                inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                                nn=nn+1;
                                if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                    kkk=1;
                                end
                                if(nn>3)
                                    
                                    set(handles.bts_mean_tau,'String','---')
                                    set(handles.bts_std_tau,'String','---')
                                    set(handles.bts_mean_tau1,'String','---')
                                    set(handles.bts_std_tau1,'String','---')
                                    set(handles.bts_mean_tau2,'String','---')
                                    set(handles.bts_std_tau2,'String','---')
                                    set(handles.bts_mean_tau3,'String','---')
                                    set(handles.bts_std_tau3,'String','---')
                                    set(handles.bts_mean_ap1,'String','---')
                                    set(handles.bts_std_ap1,'String','---')
                                    set(handles.bts_mean_ap,'String','---')
                                    set(handles.bts_std_ap,'String','---')
                                    set(handles.bts_mean_ap2,'String','---')
                                    set(handles.bts_std_ap2,'String','---')
                                    set(handles.out_tau,'String','---')
                                    set(handles.out_tau1,'String',num2str(tau1_out))
                                    set(handles.out_tau2,'String',num2str(tau2_out))
                                    set(handles.out_tau3,'String',num2str(tau3_out))

                                    set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                    
                                    try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                    return
                                end
                            end
                            
                            intervals=0:0.5:tx;
                            a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                                ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                            h=figure;
                            try
                                prob(end+1)=0;
                                hh=bar(new_edge,prob(1:end),'histc');
                                hold on
                                
                            catch
                                prob(end+1)=0;
                                [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                                hh=bar(new_edge((index)),prob((index)),'histc');
                                zoom xon
                            end
                            
                            colormap summer;
                            hold on
                            plot(intervals,pdfEst,'b');
                            hold on
                            X =  binCtrs;
                            Y =prob(1:end-1);
                            E = error_1';
                            errorbar(X,Y(:,1),E(:,1), 'xr')
                            xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                            %                     hold off                    hold off
                            %                     h=figure;
                            %                     try
                            %                         hh=bar(binCtrs,prob,'hist');
                            %                         zoom xon
                            %                     catch
                            %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                            %                         zoom xon
                            %                     end
                            %
                            %                     colormap summer;
                            %                     hold on
                            %                     plot(binCtrs,prob);
                            %                     hold off
                            %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                            %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,1))
                            ylabel('Bootstrap Histogram(a1)');
                            [fi,xi] = ksdensity(bts(:,1));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,2))
                            ylabel('Bootstrap Histogram(a2)');
                            [fi,xi] = ksdensity(bts(:,2));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                            
                            
                            h=figure
                            hist(bts(:,3))
                            ylabel('Bootstrap Histogram(tau1)');
                            [fi,xi] = ksdensity(bts(:,3));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,4))
                            ylabel('Bootstrap Histogram(tau2)');
                            [fi,xi] = ksdensity(bts(:,4));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                            
                            h=figure
                            hist(bts(:,5))
                            ylabel('Bootstrap Histogram(tau3)');
                            [fi,xi] = ksdensity(bts(:,5));
                            saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                            h=figure;
                            plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                            %plot(xi,fi)
                            saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                            
                            
                            Out.hist.bincounts=bincounts;
                            Out.hist.bincenters=bincenters;
                            Out.PD.prob=prob;
                            Out.PDEST.pdfEst=pdfEst;
                            Out.bootstrp=bts;
                            Out.bootstrp_mean_tau1=mean(bts(:,3));
                            Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                            Out.bootstrp_mean_tau2=mean(bts(:,4));
                            Out.bootstrp_std_tau2=std(bts(:,4));
                            Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                            Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                            Out.bootstrp_mean_a2=mean(bts(:,2));
                            Out.bootstrp_std_a2=std(bts(:,2));
                            Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                            Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                            %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                            save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                            set(handles.bts_mean_tau,'String','---')
                            set(handles.bts_std_tau,'String','---')
                            set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                            set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                            set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                            set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                            set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                            set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                            set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                            set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                            set(handles.out_tau,'String','---')
                            set(handles.out_tau1,'String',num2str(tau1_out))
                            set(handles.out_tau2,'String',num2str(tau2_out))
                            set(handles.out_tau3,'String',num2str(tau3_out))

                            set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                            
                    end
                    %         close all
                    
                    
                    
                end
                
                
            end
            
            
            
            status11 = (get(handles.manual,'Value'));
            if (status11 == 1)
                x=inputdlg('Enter space-seprated numbers','Experimental(Interval) Length',[1 50]);
                data=str2num(x{:});
                
                optN=size(data,2)-1;
                
                OUTPUT_DIR2=OUTPUT_DIR1;
                OUTPUT_DIR2=[OUTPUT_DIR2 '_manual'];
%                 if ~exist(OUTPUT_DIR2,'dir');
%                     mkdir(OUTPUT_DIR2);
%                 end
                tt=[tt1 ',manual '];
                
                
                switch popup_sel_index3
                    case 1
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        tau_out=fminsearch('expfallone_mxl_2',tau,[],EventLengths,tm,tx);
                        if(tau_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            bts=btstrp_exp1(nboot,tau_out,EventLengths,tm,tx);
                            nn=nn+1;
                           if(mean(bts)<(2*tau_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String',num2str(tau_out))
                                set(handles.out_tau1,'String','---')
                                set(handles.out_tau2,'String','---')
                                set(handles.out_tau3,'String','---')
                                set(handles.out_ap,'String','---')
                                set(handles.out_ap1,'String','---')
                                set(handles.out_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        
                        intervals=0:0.5:tx;
                        tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        h=figure
                        hist(bts)
                        ylabel('Bootstrap Histogram');
                        [fi,xi] = ksdensity(bts);
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                        h=figure;
                        %plot(xi,fi)
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                        
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau=mean(bts);
                        Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        set(handles.bts_mean_tau1,'String','---')
                        set(handles.bts_std_tau1,'String','---')
                        set(handles.bts_mean_tau2,'String','---')
                        set(handles.bts_std_tau2,'String','---')
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String','---')
                        set(handles.bts_std_ap,'String','---')
                        set(handles.bts_mean_ap1,'String','---')
                        set(handles.bts_std_ap1,'String','---')
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String',num2str(tau_out))
                        set(handles.out_tau1,'String','---')
                        set(handles.out_tau2,'String','---')
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String','---')
                        set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        
                        
                    case 2
                        
                        
                        %                     fcn
                        %                    bts=btstrp_exp1_all(nboot,inarg,EventLengths1,EventLengths2,tm);
                        %                     [pf,pdfEst]=expfallone_all_events_mxl(tau,bincenters,mxintervals,tm);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallone_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        
                        tau_out=fminsearch('expfallone_all_events_mxl',tau,[],EventLengths1,EventLengths2,tm);
                        if(tau_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            bts=btstrp_exp1_all(nboot,tau_out,EventLengths1,EventLengths2,tm);
                            nn=nn+1;
                           if(mean(bts)<(2*tau_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String',num2str(tau_out))
                                set(handles.out_tau1,'String','---')
                                set(handles.out_tau2,'String','---')
                                set(handles.out_tau3,'String','---')
                                set(handles.out_ap,'String','---')
                                set(handles.out_ap1,'String','---')
                                set(handles.out_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        
                        intervals=0:0.5:tx;
                        tau=tau_out;pdfEst=( 1/( exp(-tm/tau) - exp(-tx/tau)) )*(1/tau)*exp(-intervals/tau);
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        h=figure
                        hist(bts)
                        ylabel('Bootstrap Histogram');
                        [fi,xi] = ksdensity(bts);
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram.jpg'],'jpg')
                        h=figure;
                        %plot(xi,fi)
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples');
                        
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples.jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau=mean(bts);
                        Out.bootstrp_std_tau=std(bts);Out.tau=tau_out;
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String',num2str(mean(bts)))
                        set(handles.bts_std_tau,'String',num2str(std(bts)))
                        set(handles.bts_mean_tau1,'String','---')
                        set(handles.bts_std_tau1,'String','---')
                        set(handles.bts_mean_tau2,'String','---')
                        set(handles.bts_std_tau2,'String','---')
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String','---')
                        set(handles.bts_std_ap,'String','---')
                        set(handles.bts_mean_ap1,'String','---')
                        set(handles.bts_std_ap1,'String','---')
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String',num2str(tau_out))
                        set(handles.out_tau1,'String','---')
                        set(handles.out_tau2,'String','---')
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String','---')
                        set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        
                        
                    case 3
                        inarg = [ ap tau1 tau2];
                        a=1/(1+inarg(1)^2);
                        tau1=abs(inarg(2));
                        tau2=abs(inarg(3));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        fn=fminsearch('expfalltwo_mxl',inarg,[],EventLengths,tm,tx);
                        ap_out=fn(:,1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                        tau1_out=fn(:,2);
                        tau2_out=fn(:,3);
                        if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2(nboot,inarg,EventLengths,tm,tx);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        thyme=intervals;
                        a=a1_out;tau1=tau1_out; tau2=tau2_out;pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        hold on
                        plot(intervals,pdfEst,'b');
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(a1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,2));
                        Out.bootstrp_std_tau1=std(bts(:,2));
                        Out.bootstrp_mean_tau2=mean(bts(:,3));
                        Out.bootstrp_std_tau2=std(bts(:,3));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                        Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                        
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                        
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    case 4
                        
                        %                 fcn=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                        %                 bts=btstrp_exp2_all(nboot,inarg,EventLengths,mxintervals,tm);
                        inarg = [ ap tau1 tau2];
                        a=1/(1+inarg(1)^2);
                        tau1=abs(inarg(2));
                        tau2=abs(inarg(3));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalltwo_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        out_x=fminsearch('expfalltwo_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                        ap_out=out_x(1); a1_out=1/(1+(ap_out^2)); a2_out=1-a1_out;
                        
                        tau1_out=out_x(2);
                        tau2_out=out_x(3);
                        if(a1_out<0 ||tau1_out<0 ||tau2_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap_out tau1_out tau2_out];bts=btstrp_exp2_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc=bts(:,1); bts(:,1)=1./(1+(xc.^2));clear xc;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(3*tau1_out) && mean(bts(:,3))<(3*tau2_out))
                                kkk=1;
                            end
                            if(nn>3)
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        intervals=0:0.5:tx;
                        thyme=intervals;
                        a=a1_out; tau1=tau1_out; tau2=tau2_out; pdfEst=1/(a*(exp(-tm/tau1)-exp(-tx/tau2))+(1-a)*(exp(-tm/tau2)-exp(-tx/tau2)))*(a/tau1*exp(-thyme/tau1)+(1-a)/tau2*exp(-thyme/tau2));
                        
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        %
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(a1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi); ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,2));
                        Out.bootstrp_std_tau1=std(bts(:,2));
                        Out.bootstrp_mean_tau2=mean(bts(:,3));
                        Out.bootstrp_std_tau2=std(bts(:,3));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.bootstrp_mean_a2=(1-mean(bts(:,1)));Out.ap=ap_out;Out.a2=a2_out;
                        Out.bootstrp_std_a=std(bts(:,1));Out.a1=a1_out;Out.tau1=tau1_out;Out.tau2=tau2_out;
                        
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,2))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,2))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau3,'String','---')
                        set(handles.bts_std_tau3,'String','---')
                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(1-mean(bts(:,1))))
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(1-std(bts(:,1))))
                        
                        set(handles.bts_mean_ap2,'String','---')
                        set(handles.bts_std_ap2,'String','---')
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String','---')
                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out))
                        % set(handles.out_ap1,'String','---')
                        set(handles.out_ap2,'String','---')
                    case 5
                        
                        %                 fcn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                        %                 inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                        inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                        a1=1/(1+inarg(1)^2);
                        a2=(1-a1)/(1+inarg(2)^2);
                        tau1=abs(inarg(3));
                        tau2=abs(inarg(4));
                        tau3=abs(inarg(5));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfallthree_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        mn=fminsearch('expfallthree_mxl',inarg,[],EventLengths,tm,tx);
                        ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                        ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                        tau1_out=mn(3);
                        tau2_out=mn(4);
                        tau3_out=mn(5);
                        if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3(nboot,inarg,EventLengths,tm,tx);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                kkk=1;
                            end
                            if(nn>3)
                                
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String','---')
                                set(handles.out_tau1,'String',num2str(tau1_out))
                                set(handles.out_tau2,'String',num2str(tau2_out))
                                set(handles.out_tau3,'String',num2str(tau3_out))

                                set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                            ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(ap1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(ap1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(a2)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                        
                        
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,4))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,4));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,5))
                        ylabel('Bootstrap Histogram(tau3)');
                        [fi,xi] = ksdensity(bts(:,5));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                        
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,3));
                        Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                        Out.bootstrp_mean_tau2=mean(bts(:,4));
                        Out.bootstrp_std_tau2=std(bts(:,4));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                        Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                        Out.bootstrp_mean_a2=mean(bts(:,2));
                        Out.bootstrp_std_a2=std(bts(:,2));
                        Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                        Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                        set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                        set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String',num2str(tau3_out))

                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                    case 6
                        
                        %                 fcn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths,mxintervals,tm);
                        inarg = [ ap1 ap2 tau1 tau2 tau3 ];
                        a1=1/(1+inarg(1)^2);
                        a2=(1-a1)/(1+inarg(2)^2);
                        tau1=abs(inarg(3));
                        tau2=abs(inarg(4));
                        tau3=abs(inarg(5));
                        
                        %                     [pf,pdfEst]=expfalltwo_mxll(inarg,bincenters,tm,tx);
                        %                     m= bootstrp(100,@mean,prob);
                        
                        OUTPUT_DIR=[OUTPUT_DIR2 '_expfalthree_all_events_mxl'];
                        if ~exist(OUTPUT_DIR,'dir');
                            mkdir(OUTPUT_DIR);
                        end
                        [bincounts,bincenters,error_1,prob,new_edge]= histfit1(EventLengths,data,'exponential',tt,OUTPUT_DIR,Nelement);
                        binCtrs=new_edge(1:end-1)+diff(new_edge)/2;
                        if(length(EventLengths2)==0)
                           msgbox('Vector list of intervals for spots that do NOT vanish is empty! we are not able to test out a MLA for fitting a dist.'),set(handles.busy,'String','');
                            return
                        end
                        mn=fminsearch('expfalthree_all_events_mxl',inarg,[],EventLengths1,EventLengths2,tm);
                        
                        ap1_out=mn(1);a1_out=1/(1+(ap1_out^2));
                        ap2_out=mn(2); a2_out=(1-a1_out)/(1+(ap2_out^2)); a3_out=1-a1_out-a2_out;
                        tau1_out=mn(3);
                        tau2_out=mn(4);
                        tau3_out=mn(5);
                        if(tau1_out<0 ||tau2_out<0||tau3_out<0)
                           msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
                            return
                        end
                        kkk=0;
                        nn=0;
                        while(kkk==0)
                            inarg = [ ap1_out ap2_out tau1_out tau2_out tau3_out ];bts=btstrp_exp3_all(nboot,inarg,EventLengths1,EventLengths2,tm);xc1=bts(:,1);xc2=bts(:,2);bts(:,1)=1./(1+(xc1.^2)); bts(:,2)=(1-bts(:,1))./(1+(xc2.^2));clear xc1 xc2;
                            nn=nn+1;
                            if(mean(bts(:,1))<(5*a1_out) && mean(bts(:,2))<(5*a2_out) && mean(bts(:,3))<(3*tau1_out)&& mean(bts(:,4))<(3*tau2_out)&& mean(bts(:,5))<(3*tau3_out))
                                kkk=1;
                            end
                            if(nn>3)
                                
                                set(handles.bts_mean_tau,'String','---')
                                set(handles.bts_std_tau,'String','---')
                                set(handles.bts_mean_tau1,'String','---')
                                set(handles.bts_std_tau1,'String','---')
                                set(handles.bts_mean_tau2,'String','---')
                                set(handles.bts_std_tau2,'String','---')
                                set(handles.bts_mean_tau3,'String','---')
                                set(handles.bts_std_tau3,'String','---')
                                set(handles.bts_mean_ap1,'String','---')
                                set(handles.bts_std_ap1,'String','---')
                                set(handles.bts_mean_ap,'String','---')
                                set(handles.bts_std_ap,'String','---')
                                set(handles.bts_mean_ap2,'String','---')
                                set(handles.bts_std_ap2,'String','---')
                                set(handles.out_tau,'String','---')
                                set(handles.out_tau1,'String',num2str(tau1_out))
                                set(handles.out_tau2,'String',num2str(tau2_out))
                                set(handles.out_tau3,'String',num2str(tau3_out))

                                set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                                
                                try Error.EventLengths=EventLengths; catch Error.EventLengths=[]; end,try Error.EventLengths1=EventLengths1; catch Error.EventLengths1=[]; end,try Error.EventLengths2=EventLengths2; catch Error.EventLengths2=[]; end,   msgbox(' we are not able to calculate a distribution of fit parameters from fitting a data set of binding intervals'),set(handles.busy,'String','');; save([OUTPUT_DIR '/Error.mat'],'-struct','Error');
                                return
                            end
                        end
                        
                        intervals=0:0.5:tx;
                        a1=a1_out; a2=a2_out;tau1=tau1_out; tau2=tau2_out; tau3=tau3_out;pdfEst=(  1/ ( a1*(exp(-tm/tau1)-exp(-tx/tau2))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3)) )  )*...
                            ( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) );
                        h=figure;
                        try
                            prob(end+1)=0;
                            hh=bar(new_edge,prob(1:end),'histc');
                            hold on
                            
                        catch
                            prob(end+1)=0;
                            [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                            hh=bar(new_edge((index)),prob((index)),'histc');
                            zoom xon
                        end
                        
                        colormap summer;
                        hold on
                        plot(intervals,pdfEst,'b');
                        hold on
                        X =  binCtrs;
                        Y =prob(1:end-1);
                        E = error_1';
                        errorbar(X,Y(:,1),E(:,1), 'xr')
                        xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        saveas(h,[OUTPUT_DIR '/pdf.jpg'],'jpg')
                        hold off
                        %                     h=figure;
                        %                     try
                        %                         hh=bar(binCtrs,prob,'hist');
                        %                         zoom xon
                        %                     catch
                        %                         [junk,index] = unique(prob,'first');        %# Capture the index, ignore junk
                        %                         hh=bar(binCtrs((index)),prob((index)),'hist');
                        %                         zoom xon
                        %                     end
                        %
                        %                     colormap summer;
                        %                     hold on
                        %                     plot(binCtrs,prob);
                        %                     hold off
                        %                     xlabel([tt],'FontWeight','b','FontSize',12); ylabel('Probability Density');
                        %                     saveas(h,[OUTPUT_DIR '/pdf1.jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,1))
                        ylabel('Bootstrap Histogram(ap1)');
                        [fi,xi] = ksdensity(bts(:,1));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(ap1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,2))
                        ylabel('Bootstrap Histogram(a2)');
                        [fi,xi] = ksdensity(bts(:,2));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(a2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(a2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(a2).jpg'],'jpg')
                        
                        
                        h=figure
                        hist(bts(:,3))
                        ylabel('Bootstrap Histogram(tau1)');
                        [fi,xi] = ksdensity(bts(:,3));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau1).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau1)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau1).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,4))
                        ylabel('Bootstrap Histogram(tau2)');
                        [fi,xi] = ksdensity(bts(:,4));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau2).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau2)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau2).jpg'],'jpg')
                        
                        h=figure
                        hist(bts(:,5))
                        ylabel('Bootstrap Histogram(tau3)');
                        [fi,xi] = ksdensity(bts(:,5));
                        saveas(h,[OUTPUT_DIR '/Bootstrap_Histogram(tau3).jpg'],'jpg')
                        h=figure;
                        plot(xi,fi);ylabel('Density Estimation of Bootstrap Samples(tau3)');
                        %plot(xi,fi)
                        saveas(h,[OUTPUT_DIR '/bootstrap_samples(tau3).jpg'],'jpg')
                        
                        
                        Out.hist.bincounts=bincounts;
                        Out.hist.bincenters=bincenters;
                        Out.PD.prob=prob;
                        Out.PDEST.pdfEst=pdfEst;
                        Out.bootstrp=bts;
                        Out.bootstrp_mean_tau1=mean(bts(:,3));
                        Out.bootstrp_std_tau1=std(bts(:,3));Out.ap1=ap1_out;Out.ap2=ap2_out;
                        Out.bootstrp_mean_tau2=mean(bts(:,4));
                        Out.bootstrp_std_tau2=std(bts(:,4));
                        Out.bootstrp_mean_a1=mean(bts(:,1));Out.ap1=ap1_out;
                        Out.bootstrp_std_a1=std(bts(:,1));Out.a1=a1_out;
                        Out.bootstrp_mean_a2=mean(bts(:,2));
                        Out.bootstrp_std_a2=std(bts(:,2));
                        Out.bootstrp_mean_tau3=mean(bts(:,5)); Out.a3=a3_out;
                        Out.bootstrp_std_tau3=std(bts(:,5));Out.a1=a1_out;Out.a2=a2_out;Out.tau1=tau1_out;Out.tau2=tau2_out;Out.tau3=tau3_out;
                        %         clear Chk_sel_index EventLengths Intervals N N1 N2 N3 N4 N5 binCtrs bincenters bincounts bn bootstrp_data data eventdata logik logik1 logik2 logik3 logik4 logik5  nbins pdfEst prob tt xgrid
                        save([OUTPUT_DIR '/result.mat'],'-struct','Out');
                        set(handles.bts_mean_tau,'String','---')
                        set(handles.bts_std_tau,'String','---')
                        set(handles.bts_mean_tau1,'String',num2str(mean(bts(:,3))))
                        set(handles.bts_std_tau1,'String',num2str(std(bts(:,3))))
                        set(handles.bts_mean_tau2,'String',num2str(mean(bts(:,4))))
                        set(handles.bts_std_tau2,'String',num2str(std(bts(:,4))))
                        set(handles.bts_mean_tau3,'String',num2str(mean(bts(:,5))))
                        set(handles.bts_std_tau3,'String',num2str(std(bts(:,5))))

                        set(handles.bts_mean_ap,'String',num2str(mean(bts(:,1)))),set(handles.bts_mean_ap1,'String',num2str(mean(bts(:,2)))),set(handles.bts_mean_ap2,'String',num2str(1-mean(bts(:,1))-mean(bts(:,2))));
                        set(handles.bts_std_ap,'String',num2str(std(bts(:,1)))),set(handles.bts_std_ap1,'String',num2str(std(bts(:,2)))),set(handles.bts_std_ap2,'String',num2str(1-std(bts(:,1))-std(bts(:,2))));
                        set(handles.out_tau,'String','---')
                        set(handles.out_tau1,'String',num2str(tau1_out))
                        set(handles.out_tau2,'String',num2str(tau2_out))
                        set(handles.out_tau3,'String',num2str(tau3_out))

                        set(handles.out_ap,'String',num2str(a1_out)),set(handles.out_ap1,'String',num2str(a2_out)),set(handles.out_ap2,'String',num2str(a3_out));
                        
                end
                %         close all
                
                
                
            end
            
            
            
            
            
            % figure;
            % %histfit_normalization(EventLengths,data,'exponential');
            % pdfplot(EventLengths);
            % colormap summer;
            % Add a legend
        else
            %      creates a message dialog box that automatically wraps Message to fit an appropriately sized figure.
            Message=['No member equal to ' num2str(N)];
            h = msgbox(Message)
        end
    end
catch
   msgbox(' we are not able to fit a distribution function'),set(handles.busy,'String','');
end
set(handles.busy,'String','')



% Add title and axis labels
% title('Histogram of .........');
% xlabel('Occurrences');
% ylabel('Number of sequence reads');



% g=1/sqrt(2*pi)*exp(-0.5*x.^2);%# pdf of the normal distribution
% f(f==0)=[];
% %#METHOD 1: DIVIDE BY SUM
% figure(1)
% bar(x,f/sum(f));hold on
% plot(x,g,'r');hold off
%
% %#METHOD 2: DIVIDE BY AREA
% figure(2)
% bar(x,f/trapz(x,f));hold on
% plot(x,g,'r');hold off
% N=histc(EventLengths,data);

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, ~)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figure1)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figure1,'Name') '?'],...
    ['Close ' get(handles.figure1,'Name') '...'],...
    'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figure1)


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
% n=handles.popupmenu1;

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%set(hObject, 'String', {'plot(rand(5))', 'plot(sin(1:0.01:25))',
%'bar(1:.5:10)', 'plot(membrane)', 'surf(peaks)'});Fatemeh
set(hObject, 'String', {'-3', '-2', '0', '1', '2', '3'...
    ...
    '-3,-2', '-3,0', '-3,1', '-3,2', '-3,3', '-2,0', '-2,1', '-2,3', '0,1','0,2','0,3','1,2','1,3','2,3'...
    ...
    '-3,-2,0', '-3,-2,1', '-3,-2,2', '-3,-2,3','-3,0,1' ,'-3,0,2' , '-3,0,3','-3,1,2' ,'-3,1,3','-3,2,3','-2,0,1', '-2,0,2', '-2,0,3','-2,1,2','-2,1,3'...
    ...
    ,'0,1,2', '0,1,3','0,2,3' ,'1,2,3'...
    ...
    '-3,-2,0,1', '-3,-2,0,2', '-3,-2,0,3', '-3,-2,1,2','-3,-2,1,3', '-3,-2,2,3' ,'-3,0,1,2' ,'-3,0,1,3' ,'-3,0,2,1', '-3,0,2,3', '-3,1,2,3' , '-2,0,1,2', '-2,0,1,3', '-2,0,2,3','-2,1,2,3' '0,1,2,3'...
    ...
    '-3,-2,0,1,2', '-3,-2,0,1,3','-3,-2,0,2,3', '-3,-2,1,2,3', '-3,0,1,2,3','-2,0,1,2,3'...
    ...
    '-3,-2,0,1,2,3'...
    });

% function unitgroup_SelectionChangeFcn(hObject, eventdata, handles)
% % hObject    handle to the selected object in unitgroup
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
%
% if (hObject == handles.time)
%
% else
%
% end




% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', {'Millisecond', 'Second', 'Minute'});


% --- Executes on button press in Time.
function Time_Callback(hObject, eventdata, handles)
% hObject    handle to Time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Time
Chk_sel_index = get(handles.Time, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end

% --- Executes on button press in Frame.
function Frame_Callback(hObject, eventdata, handles)
% hObject    handle to Frame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Chk_sel_index = get(handles.Frame, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end
% Hint: get(hObject,'Value') returns toggle state of Frame


% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
popup_sel_index3 = get(handles.popupmenu3, 'Value');

switch popup_sel_index3
    case 1
        set(handles.text22,'String','  f=1/(( exp(-tm/tau) - exp(-tx/tau) ) )* (1/tau)*exp(-intervals/tau)')
        set(handles.ap, 'enable', 'off')
        set(handles.ap1, 'enable', 'off')
        set(handles.ap2, 'enable', 'off')
        
        
        set(handles.tau1, 'enable', 'off')
        set(handles.tau2, 'enable', 'off')
        set(handles.tau3, 'enable', 'off')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'on')
        
    case 2
        
        set(handles.text22,'String','f1=( 1/( exp(-tm/tau)) )* (1/tau)*exp(-intervals/tau),f2=( 1/( exp(-tm/tau)) )* exp(-mxintervals/tau)')
        
        set(handles.ap, 'enable', 'off')
        set(handles.ap1, 'enable', 'off')
        set(handles.ap2, 'enable', 'off')
        
        
        set(handles.tau1, 'enable', 'off')
        set(handles.tau2, 'enable', 'off')
        set(handles.tau3, 'enable', 'off')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'on')
    case 3
        
        set(handles.text22,'String','a1=1/(1+ap^2),  a2=1-a1,  f1=1/ ( a*(exp(-tm/tau1)-exp(-tx/tau2)) + (1-a)*(exp(-tm/tau2)-exp(-tx/tau2)) )  )*( a/tau1 *exp(-intervals/tau1)+(1-a)/tau2 *exp(-intervals/tau2)')
        set(handles.ap, 'enable', 'on')
        set(handles.ap1, 'enable', 'off')
        set(handles.ap2, 'enable', 'off')
        
        
        set(handles.tau1, 'enable', 'on')
        set(handles.tau2, 'enable', 'on')
        set(handles.tau3, 'enable', 'off')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'off')
    case 4
        set(handles.text22,'String','a1=1/(1+inarg(1)^2),  a2=1-a1,  A=exp(-tm/tau1),B =exp(-tm/tau2),f1=(  1/( a*A + (1-a)*B  ) )*( a/tau1*exp(-intervals/tau1)+(1-a)/tau2*exp(-intervals/tau2)),f2=(  1/( a*A + (1-a)*B  ) )*( a*exp(-mxintervals/tau1)+(1-a)*exp(-mxintervals/tau2) )')
        
        set(handles.ap, 'enable', 'on')
        set(handles.ap1, 'enable', 'off')
        set(handles.ap2, 'enable', 'off')
        
        
        set(handles.tau1, 'enable', 'on')
        set(handles.tau2, 'enable', 'on')
        set(handles.tau3, 'enable', 'off')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'off')
    case 5
        set(handles.text22,'String','a1=1/(1+ap1^2),  a2=(1-a1)/(1+ap2^2),  a3=1-a1-a2,  f=(1/( a1*(exp(-tm/tau1)-exp(-tx/tau1))+a2*(exp(-tm/tau2)-exp(-tx/tau2))+(1-a1-a2)*(exp(-tm/tau3)-exp(-tx/tau3))))*( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+  (1-a1-a2)/tau3*exp(-intervals/tau3))')
        
        
        set(handles.ap, 'enable', 'off')
        set(handles.ap1, 'enable', 'on')
        set(handles.ap2, 'enable', 'on')
        
        
        set(handles.tau1, 'enable', 'on')
        set(handles.tau2, 'enable', 'on')
        set(handles.tau3, 'enable', 'on')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'off')
    case 6
        
        set(handles.text22,'String','a1=1/(1+ap1^2),    a2=(1-a1)/(1+ap2^2),    a3=1-a1-a2, A=exp(-tm/tau1),B=exp(-tm/tau2),C=exp(-tm/tau3),f1=(  1/( a1*A + (a2)*B + (1-a1-a2)*C  ) )*( a1/tau1*exp(-intervals/tau1)+a2/tau2*exp(-intervals/tau2)+(1-a1-a2)/tau3*exp(-intervals/tau3) ),f2=(1/( a1*A + (a2)*B + (1-a1-a2)*C ) )*( a1*exp(-mxintervals/tau1)+a2*exp(-mxintervals/tau2)+(1-a1-a2)*exp(-mxintervals/tau3))')
        set(handles.ap, 'enable', 'off')
        set(handles.ap1, 'enable', 'on')
        set(handles.ap2, 'enable', 'on')
        
        
        set(handles.tau1, 'enable', 'on')
        set(handles.tau2, 'enable', 'on')
        set(handles.tau3, 'enable', 'on')
        set(handles.tx, 'enable', 'on')
        set(handles.tm, 'enable', 'on')
        set(handles.nboot, 'enable', 'on')
        set(handles.tau, 'enable', 'off')
end



% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', {'Expfallone_mxl','Expfallone_all_events_mxl', 'Expfalltwo_mxl','Expfalltwo_all_events_mxl', 'Expfallthree_mxl','Expfalthree_all_events_mxl'});



% text(3*pi/4,sin(3*pi/4),...
% 	['sin(3*pi/4) = ',num2str(sin(3*pi/4))],...
% 	'HorizontalAlignment','center',...
% 	'BackgroundColor',[.7 .9 .7]);

function tx_Callback(hObject, eventdata, handles)
% hObject    handle to tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tx as text
%        str2double(get(hObject,'String')) returns contents of tx as a double
tx = str2double(get(hObject, 'String'));
if isnan(tx)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tx = tx;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tx_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tx (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tm_Callback(hObject, eventdata, handles)
% hObject    handle to tm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tm as text
%        str2double(get(hObject,'String')) returns contents of tm as a double
tm = str2double(get(hObject, 'String'));
if isnan(tm)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tm = tm;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tau_Callback(hObject, eventdata, handles)
% hObject    handle to tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau as text
%        str2double(get(hObject,'String')) returns contents of tau as a double
tau= str2double(get(hObject, 'String'));
if isnan(tau)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tau = tau;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tau_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nboot_Callback(hObject, eventdata, handles)
% hObject    handle to nboot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nboot as text
%        str2double(get(hObject,'String')) returns contents of nboot as a double
nboot= str2double(get(hObject, 'String'));
if isnan(nboot)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.nboot = nboot;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function nboot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nboot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ap_Callback(hObject, eventdata, handles)
% hObject    handle to ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ap as text
%        str2double(get(hObject,'String')) returns contents of ap as a double
ap= str2double(get(hObject, 'String'));
if isnan(ap)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.ap = ap;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function ap_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tau1_Callback(hObject, eventdata, handles)
% hObject    handle to tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau1 as text
%        str2double(get(hObject,'String')) returns contents of tau1 as a double
tau1= str2double(get(hObject, 'String'));
if isnan(tau1)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tau1 = tau1;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tau1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tau2_Callback(hObject, eventdata, handles)
% hObject    handle to tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau2 as text
%        str2double(get(hObject,'String')) returns contents of tau2 as a double
tau2= str2double(get(hObject, 'String'));
if isnan(tau2)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tau2 = tau2;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tau2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tau3_Callback(hObject, eventdata, handles)
% hObject    handle to tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tau3 as text
%        str2double(get(hObject,'String')) returns contents of tau3 as a double
tau3= str2double(get(hObject, 'String'));
if isnan(tau3)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.tau3 = tau3;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function tau3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function ap1_Callback(hObject, eventdata, handles)
% hObject    handle to ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ap1 as text
%        str2double(get(hObject,'String')) returns contents of ap1 as a double
ap1= str2double(get(hObject, 'String'));
if isnan(ap1)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.ap1 = ap1;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function ap1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ap2_Callback(hObject, eventdata, handles)
% hObject    handle to ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ap2 as text
%        str2double(get(hObject,'String')) returns contents of ap2 as a double
ap2= str2double(get(hObject, 'String'));
if isnan(ap2)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new volume value
handles.metricdata.ap2 = ap2;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function ap2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%
% % --- Executes during object creation, after setting all properties.
% function tau3_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to tau3 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
%
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end



function bts_mean_tau_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_tau as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_tau as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_tau_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_tau_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_tau as text
%        str2double(get(hObject,'String')) returns contents of bts_std_tau as a double


% --- Executes during object creation, after setting all properties.
function bts_std_tau_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Scott.
function Scott_Callback(hObject, eventdata, handles)
% hObject    handle to Scott (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Scott
Chk_sel_index = get(handles.Scott, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end


% --- Executes on button press in Sturges.
function Sturges_Callback(hObject, eventdata, handles)
% hObject    handle to Sturges (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Sturges
Chk_sel_index = get(handles.Sturges, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end

% --- Executes on button press in middle.
function middle_Callback(hObject, eventdata, handles)
% hObject    handle to middle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of middle
Chk_sel_index = get(handles.middle, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end

% --- Executes on button press in opt.
function opt_Callback(hObject, eventdata, handles)
% hObject    handle to opt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of opt
Chk_sel_index = get(handles.opt, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end

% --- Executes on button press in all.
function all_Callback(hObject, eventdata, handles)
% hObject    handle to all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of all
Chk_sel_index = get(handles.all, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
    set(handles.fd, 'Value',1);
    set(handles.opt, 'Value',1);
    set(handles.middle, 'Value',1);
    set(handles.Sturges, 'Value',1);
    set(handles.Scott, 'Value',1);
else
    set(hObject,'Value',0);
    set(hObject,'Value',0);
    set(handles.fd, 'Value',0);
    set(handles.opt, 'Value',0);
    set(handles.middle, 'Value',0);
    set(handles.Sturges, 'Value',0);
    set(handles.Scott, 'Value',0);
end

% --- Executes on button press in fd.
function fd_Callback(hObject, eventdata, handles)
% hObject    handle to fd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fd
Chk_sel_index = get(handles.fd, 'Value');
if(Chk_sel_index==1)
    set(hObject,'Value',1);
else
    set(hObject,'Value',0);
end



function bts_mean_tau1_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_tau1 as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_tau1 as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_tau1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_tau1_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_tau1 as text
%        str2double(get(hObject,'String')) returns contents of bts_std_tau1 as a double


% --- Executes during object creation, after setting all properties.
function bts_std_tau1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_mean_tau2_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_tau2 as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_tau2 as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_tau2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_tau2_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_tau2 as text
%        str2double(get(hObject,'String')) returns contents of bts_std_tau2 as a double


% --- Executes during object creation, after setting all properties.
function bts_std_tau2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_mean_tau3_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_tau3 as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_tau3 as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_tau3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_tau3_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_tau3 as text
%        str2double(get(hObject,'String')) returns contents of bts_std_tau3 as a double


% --- Executes during object creation, after setting all properties.
function bts_std_tau3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_mean_ap2_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_ap2 as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_ap2 as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_ap2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_ap2_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_ap2 as text
%        str2double(get(hObject,'String')) returns contents of bts_std_ap2 as a double


% --- Executes during object creation, after setting all properties.
function bts_std_ap2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_mean_ap_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_ap as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_ap as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_ap_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_ap_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_ap as text
%        str2double(get(hObject,'String')) returns contents of bts_std_ap as a double


% --- Executes during object creation, after setting all properties.
function bts_std_ap_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_mean_ap1_Callback(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_mean_ap1 as text
%        str2double(get(hObject,'String')) returns contents of bts_mean_ap1 as a double


% --- Executes during object creation, after setting all properties.
function bts_mean_ap1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_mean_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bts_std_ap1_Callback(hObject, eventdata, handles)
% hObject    handle to bts_std_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bts_std_ap1 as text
%        str2double(get(hObject,'String')) returns contents of bts_std_ap1 as a double


% --- Executes during object creation, after setting all properties.
function bts_std_ap1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bts_std_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_tau_Callback(hObject, eventdata, handles)
% hObject    handle to out_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_tau as text
%        str2double(get(hObject,'String')) returns contents of out_tau as a double


% --- Executes during object creation, after setting all properties.
function out_tau_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_tau (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_ap_Callback(hObject, eventdata, handles)
% hObject    handle to out_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_ap as text
%        str2double(get(hObject,'String')) returns contents of out_ap as a double


% --- Executes during object creation, after setting all properties.
function out_ap_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_ap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_ap1_Callback(hObject, eventdata, handles)
% hObject    handle to out_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_ap1 as text
%        str2double(get(hObject,'String')) returns contents of out_ap1 as a double


% --- Executes during object creation, after setting all properties.
function out_ap1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_ap1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_ap2_Callback(hObject, eventdata, handles)
% hObject    handle to out_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_ap2 as text
%        str2double(get(hObject,'String')) returns contents of out_ap2 as a double


% --- Executes during object creation, after setting all properties.
function out_ap2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_ap2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_tau1_Callback(hObject, eventdata, handles)
% hObject    handle to out_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_tau1 as text
%        str2double(get(hObject,'String')) returns contents of out_tau1 as a double


% --- Executes during object creation, after setting all properties.
function out_tau1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_tau1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_tau2_Callback(hObject, eventdata, handles)
% hObject    handle to out_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_tau2 as text
%        str2double(get(hObject,'String')) returns contents of out_tau2 as a double


% --- Executes during object creation, after setting all properties.
function out_tau2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_tau2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function out_tau3_Callback(hObject, eventdata, handles)
% hObject    handle to out_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of out_tau3 as text
%        str2double(get(hObject,'String')) returns contents of out_tau3 as a double


% --- Executes during object creation, after setting all properties.
function out_tau3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to out_tau3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in manual.
function manual_Callback(hObject, eventdata, handles)
% hObject    handle to manual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Sturges, 'enable', 'off')
set(handles.fd, 'enable', 'off')
set(handles.Scott, 'enable', 'off')
set(handles.middle, 'enable', 'off')
set(handles.opt, 'enable', 'off')
set(handles.all, 'enable', 'off')
%         set(handles.tau, 'enable', 'off')
% Hint: get(hObject,'Value') returns toggle state of manual


% --- Executes on button press in auto.
function auto_Callback(hObject, eventdata, handles)
% hObject    handle to auto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Sturges, 'enable', 'on')
set(handles.fd, 'enable', 'on')
set(handles.Scott, 'enable', 'on')
set(handles.middle, 'enable', 'on')
set(handles.opt, 'enable','on')
set(handles.all, 'enable','on')
% Hint: get(hObject,'Value') returns toggle state of auto


% --- Executes on button prestrys in usermanual.
function usermanual_Callback(hObject, eventdata, handles)
% hObject    handle to usermanual (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    winopen('PH.pdf');
catch
    system('open PH.pdf');
end
