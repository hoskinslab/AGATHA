function func_graph_intervals_time_graph_ega2(graph,time2frames,sneg,s0,s1,s2,s3,wig_type)
%This function plots the matrix graph as rectangles using non consistent
%time information from the header file of the experiment.
%graph=the matrix to be graphed [m by n]
%time2frames=time from first to last frame of graph, time2frames(i)=graph(1,i) [n by 1]
%
%File 1:    File2:  Result:(0=no peak, 1=peak -1=no data)
%-1         -1      -1 = red
%-1         0       -1
%-1         1       -1
%0          -1      -1
%0          0       0  = white    
%0          1       1  = blue
%1          -1      -1 
%1          0       2  = yellow
%1          1       3  = green
%sneg=-1, what value this is in the matrix graph
%s0=0,what value this is in the matrix graph
%s1=1,what value this is in the matrix graph
%s2=2,what value this is in the matrix graph
%s3=3,what value this is in the matrix graph

%For single files this will be only -1, 0 and 3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%V.1.0  Alex O   3/2/10

%construct the graph
figure;

switch lower(wig_type)
    case 'event_norm'    %this will plot a rastergram with a wiggle plot
                          %showing normalized number of events
        g1=graph;
        g2=graph;
        g3=graph;
        
        g1(g1==-1)=0;
        g1(g1==1)=0;
        g1(g1==2)=1; %g1 only
        g1(g1==3)=0; %g1 & g2 overlap
        
        g2(g2==-1)=0;
        g2(g2==2)=0; %g2 only
        g2(g2==3)=0; %g1 & g2 overlap
        
        graph_tot1=sum(g1)/size(g1,1);
    
        graph_tot2=sum(g2)/size(g1,1);
    
        x=1:3600;
    
        %the wiggle plot is plotted above the rastergram
        subplot(4,1,1);
   
        [AX,H1,H2]=plotyy(time2frames,graph_tot1, time2frames, graph_tot2, 'area', 'area');
        set(H1,'FaceColor',[0.91765,0.13333,0.16471],'EdgeColor',[0.91765,0.13333,0.16471]);
        set(H2,'FaceColor',[0.41176,0.74118,0.27059],'EdgeColor',[0.41176,0.74118,0.27059]);
        set(AX(1),'xtick',[],'TickLength',[0 0]);
        set(AX(2),'xtick',[],'TickLength',[0 0]);
        % set(AX(1),'xtick',[],'ytick',[], 'TickLength',[0 0]);
        % set(AX(2),'xtick',[],'ytick',[], 'TickLength',[0 0]);
        
        %now to graph the results
        subplot(4,1,2:4);
    otherwise
        %no wiggle plot, only rastergram
end
for i=1:size(graph,1) %for each row of graph
    curr=graph(i,1);
    curr_length=1;
    testgraph=size(graph,2);
    for j=2:size(graph,2) %for each element of each row of graph
        testcurr=graph(i,j);
        if graph(i,j)==curr %current value still in place
            curr_length=curr_length+1;
        else %different value, graph current
            %graph color depending on value of curr
            xpos=time2frames(j-curr_length);
            width=time2frames(j)-time2frames(j-curr_length);
            if curr==sneg %-1 No data
                rectangle('Position',[xpos,i-1,width,1],'EdgeColor','w','FaceColor','w');
            elseif curr==s0 %0 No peaks
                rectangle('Position',[xpos,i-1,width,1],'EdgeColor','w','FaceColor','w');   
            elseif curr==s1 %1 %Peak on file2
                rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.41176,0.74118,0.27059],'FaceColor',[0.41176,0.74118,0.27059]);    %DJC green            
            elseif curr==s2% 2 %peak on file1
                rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.91765,0.13333,0.16471],'FaceColor',[0.91765,0.13333,0.16471]);  %DJC red 
            elseif curr==s3% 3 %peak on both files (or just peak if only 1 file)
                rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.00000,0.44706,0.69804],'FaceColor',[0.00000,0.44706,0.69804]); %blue
            else
                'this is an error of some kind!'
                curr
            end
            curr=graph(i,j);
            curr_length=1;
        end
    end
    if curr==s0          %need to account for completely blank traces, 
       curr_length=1;    %so reset curr-length, otherwise time2frames(0)=fail
    end                  %added by ega 3/31/13
    
    %now to graph the last interval for each row
    %graph color depending on value of curr
    xpos=time2frames(j-curr_length);
    width=time2frames(j)-time2frames(j-curr_length);
    if curr==sneg %-1 No data
        rectangle('Position',[xpos,i-1,width,1],'EdgeColor','w','FaceColor','w');
    elseif curr==s0 %0 No peaks
        rectangle('Position',[xpos,i-1,width,1],'EdgeColor','w','FaceColor','w');   
    elseif curr==s1 %1 %Peak on file2
        %rectangle('Position',[xpos,i-1,width,1],'EdgeColor','b','FaceColor','b');                
        rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.41176,0.74118,0.27059],'FaceColor',[0.41176,0.74118,0.27059]);    %DJC green
    elseif curr==s2% 2 %peak on file1
        %rectangle('Position',[xpos,i-1,width,1],'EdgeColor','y','FaceColor','y');
        rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.91765,0.13333,0.16471],'FaceColor',[0.91765,0.13333,0.16471]);  %DJC red
    elseif curr==s3% 3 %peak on both files (or just peak if only 1 file)
        %rectangle('Position',[xpos,i-1,width,1],'EdgeColor','g','FaceColor','g');
        rectangle('Position',[xpos,i-1,width,1],'EdgeColor',[0.00000,0.44706,0.69804],'FaceColor',[0.00000,0.44706,0.69804]); %blue
    else
        'this is an error of some kind!'
        curr
    end
end





axis ij;
axis([time2frames(1) time2frames(end) 0 size(graph,1)]);
set(gca,'TickLength',[0 0]);

