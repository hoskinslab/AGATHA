function [bincounts,bincenters,errorfgh,prob,new_edge]= histfit1(data,edge,dist,tt,OUT,Nelement)
%HISTFIT Histogram with superimposed fitted normal density.
%   HISTFIT(DATA,NBINS) plots a histogram of the values in the vector DATA,
%   along with a normal density function with parameters estimated from the
%   data.  NBINS is the number of bars in the histogram. With one input
%   argument, NBINS is set to the square root of the number of elements in
%   DATA. 
%
%   HISTFIT(DATA,NBINS,DIST) plots a histogram with a density from the DIST
%   distribution.  DIST can take the following values:
%
%         'beta'                             Beta
%         'birnbaumsaunders'                 Birnbaum-Saunders
%         'exponential'                      Exponential
%         'extreme value' or 'ev'            Extreme value
%         'gamma'                            Gamma
%         'generalized extreme value' 'gev'  Generalized extreme value
%         'generalized pareto' or 'gp'       Generalized Pareto (threshold 0)
%         'inverse gaussian'                 Inverse Gaussian
%         'logistic'                         Logistic
%         'loglogistic'                      Log logistic
%         'lognormal'                        Lognormal
%         'negative binomial' or 'nbin'      Negative binomial
%         'nakagami'                         Nakagami
%         'normal'                           Normal
%         'poisson'                          Poisson
%         'rayleigh'                         Rayleigh
%         'rician'                           Rician
%         'tlocationscale'                   t location-scale
%         'weibull' or 'wbl'                 Weibull
%
%   H = HISTFIT(...) returns a vector of handles to the plotted lines.
%   H(1) is a handle to the histogram, H(2) is a handle to the density curve.

%   Copyright 1993-2008 The MathWorks, Inc. 
%   $Revision: 1.1.8.3 $  $Date: 2010/12/22 16:31:43 $

if ~isvector(data)
   error(message('stats:histfit:VectorRequired'));
end

% data = data(:);
% data(isnan(data)) = [];
% n = numel(data);
% 
% if nargin<2 || isempty(nbins)
%     nbins = ceil(sqrt(n));
% elseif ~isscalar(nbins) || ~isnumeric(nbins) || ~isfinite(nbins) ...
%                         || nbins~=round(nbins)
%     error(message('stats:histfit:BadNumBins'))
% end

% Do histogram calculations

n = numel(data);
for i=1:(size(edge,2)-1)
   bincenters1(i)=edge(i)+(edge(i+1)-edge(i))/2;
end
[bincounts]=histc(data,edge);
try
d=figure;    
hh=bar(edge,bincounts,'histc');
nbins=size(bincenters1,2);
catch
    d=figure;  
    [junk,index] = unique(bincounts,'first');        %# Capture the index, ignore junk
    hh=bar(edge((index)),bincounts((index)),'hist');

end
xlabel([tt],'FontWeight','b','FontSize',12);
 ylabel('Befor removing zero bins', 'FontWeight','b','FontSize',12);
%title(['Histogram of events based on ' num2str(length(data)) ' data samples @ ' num2str(nbins) ' bins'], 'FontWeight','b','FontSize',12);
grid on;
colormap summer;
saveas(d,[OUT '/Histogram_befor_removing.jpg'],'jpg')



hi=find(bincounts==0);
bincounts(hi)=[];
bincounts(end+1)=0;
edge(hi(1:end-1))=[];
new_edge=edge;
bincenters=edge(1:end-1)+diff(edge)/2;
binwidth=diff(edge);

n = length(data);
















Ntotalelement=sum(bincounts);
% bincounts(end+1)=0;
% new_edge(end+1)=new_edge(end)+0.0001;
% binwidth(end+1)=0.0001;
g=bincounts;
g1=new_edge;
for i=1:(size(g1,2)-1)
  
   errorfgh(i)=(Ntotalelement*(g(i)/Ntotalelement)*(1-g(i)/Ntotalelement))^0.5/ (binwidth(i)*Ntotalelement);
end
 
bincounts=g;
nbins=length(bincounts);

clear f t g g1 flag hj


% Fit distribution to data
if nargin<3 || isempty(dist)
    dist = 'normal';
end
try
    pd = fitdist(data,dist);
catch myException
    if isequal(myException.identifier,'stats:ProbDistUnivParam:fit:NRequired')
        % Binomial is not allowed because we have no N parameter
        error(message('stats:histfit:BadDistribution'))
    else
        % Pass along another other errors
        throw(myException)
    end
end

% Find range for plotting
q = icdf(pd,[0.0013499 0.99865]); % three-sigma range for normal distribution
x = linspace(q(1),q(2));
if ~pd.Support.iscontinuous
    % For discrete distribution use only integers
    x = round(x);
    x(diff(x)==0) = [];
end

% Plot the histogram with no gap between bars.
% hh = bar(bincenters,bincounts,'hist');
% barwitherr(errors,varargin)

if(numel(bincenters)==1)
 d=figure;    
hh=bar(new_edge,bincounts,'histc');   
else
    

try
d=figure;    
hh=bar(new_edge,bincounts,'histc');

catch
    d=figure;  
    [junk,index] = unique(bincounts,'first');        %# Capture the index, ignore junk
    hh=bar(new_edge((index)),bincounts((index)),'histc');

end
end
xlabel([tt],'FontWeight','b','FontSize',12);
 ylabel('After removing zero bins', 'FontWeight','b','FontSize',12);
title(['Histogram of events based on ' num2str(length(data)) ' data samples @ ' num2str(nbins-1) ' bins'], 'FontWeight','b','FontSize',12);
grid on;
colormap summer;
saveas(d,[OUT '/Histogram_afterremoving.jpg'],'jpg')

n = length(data);
prob =bincounts(1:end-1)./(n * binwidth');
% bincenters(end+1)=new_edge(end-1)+0.0005;
% bincenters(end+1)=new_edge(end)+0.0005;
% errorfgh(end+1)=0;
% errorfgh(end+1)=0;
% prob(end+1)=0;
% prob(end+1)=0;

% try
% m=figure;    
% hh=bar(bincenters,bincounts,'hist');
% colormap summer;
% hold on
% X =  bincenters;
% Y =bincounts';
%  E = errorfgh';
% errorbar(X,Y(:,1),E(:,1), 'xr')
% catch
%     m=figure;  
%     [junk,index] = unique(bincounts,'first');        %# Capture the index, ignore junk
%     hh=bar(bincenters((index)),bincounts((index)),'hist');
% colormap summer;
% hold on
% X = bincenters((index));
% Y =bincounts((index))';
%  E = errorfgh((index))';
% errorbar(X,Y(:,1),E(:,1), 'xr')
% end
% 
% xlabel([tt],'FontWeight','b','FontSize',12);
% % ploterrhist(errorfgh,'bins',16)
% title(['Errorbar ' num2str(length(data)) ' data samples  ' ], 'FontWeight','b','FontSize',12);
% grid on;
% saveas(m,[OUT '/errorbar.jpg'],'jpg')
% try
%     d=figure;
%     hh=bar(bincenters,bincounts,'hist');
%     colormap summer
%     figure
%     h = barwitherr(errorfgh, bincounts)
%    hold on
%     errorbar(bincenters,errorfgh,std(errorfgh)*ones(size(bincenters)),'rx')
%    hold off
% catch
%     d=figure;
%     [junk,index] = unique(bincounts,'first');        %# Capture the index, ignore junk
%     hh=bar(bincenters((index)),bincounts((index)),'hist');
%     colormap summer
%       
%     errorbar(bincenters((index)),errorfgh((index)),std(errorfgh((index)))*ones(size(bincenters((index)))),'rx')
%       
% end
% Normalize the density to match the total area of the histogram
% xd = get(hh,'Xdata');             % Gets the x-data of the bins.
% rangex = max(xd(:)) - min(xd(:)); % Finds the range of this data.
% binwidth = rangex/nbins;          % Finds the width of each bin.
% area = n * binwidth;
% y = area * pdf(pd,x);
% 
% % Overlay the density
% np = get(gca,'NextPlot');    
% set(gca,'NextPlot','add')    
% hh1 = plot(x,y,'r-','LineWidth',2);
% 
% if nargout == 1
%   h = [hh; hh1];
% end
% 
% set(gca,'NextPlot',np) 
