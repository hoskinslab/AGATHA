function graph=func_graph_intervals2_ega(file_path,header_path,min_frame,max_frame,spot_number,silent)
%file_path= file path
%the size of the grapgh will be [spot_number x (max_frame-min_frame)]
%if the area requested is bigger than the file, you will get a border of
%unused space.
%header_path= the path to a header file to use for the frames to time change. 
                %this should be a matlab .mat file.


%example:
%out=func_graph_intervals('C:\Users\Alex\Documents\MATLAB\hoskins100409_cy5tmp_600uW_intervals.dat',header.mat,1223,2403,49,0);
%this gives the entire file.

%silent=boolean value, if 1 then this function will not plot the figure.

%[name path]=uigetfile('D:\matlab\images','pick an interval file to load');
%if path==0 %do not proceed if uigetfile is cancelled
%    'cancelled loading file!'
%    return;
%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%V.1.1  Alex O   3/1/10
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%now uses non consistent time information and graphs as rectangles instead
%of as a matrix
%V.2  Alex O   3/2/10



loaded=load(file_path,'-mat');
intervals=loaded.Intervals.CumulativeIntervalArray;
%load header file and get frames to time info




graph=zeros(spot_number,max_frame-min_frame+1)-4;
spot=[];
spot_counter=0;
frame_counter=0;
for i=1:size(intervals,1)
   if intervals(i,1)== -2 || intervals(i,1)== -3 %start of new spot
       spot_counter=spot_counter+1;
       frame_counter=0;
       if spot_counter>spot_number %graphed the number of spots wanted
          break; 
       end
       %If not started at beginning will fill in gap here
       if intervals(i,2)>min(intervals(:,2)) && min_frame<intervals(i,2)
           gap=intervals(i,2)-min_frame; %the gap to fill (if min frame was the min of intervals(:,2)
           frame_diff=min_frame-min(intervals(:,2));%additional difference if min_frame is not = to intervals(:,2)
           if frame_diff>0
               frame_diff=0;
           end
           graph(spot_counter,1:gap+frame_diff)=-4;
           frame_counter=frame_counter+gap+frame_diff;
       end
   end
   %will fill in gaps between intervals here
   if i>1 %not first element
       gap=intervals(i,2)-intervals(i-1,3);
       if gap>1 %will now fill gap with -4
           graph(spot_counter,frame_counter:frame_counter+gap-1)=-4;
           frame_counter=frame_counter+gap-1;
       end
   end
   %now will set rgb values of pixels at (x,y)=(spot_counter,frame_counter)
   %set rgb values depending on spot
   for j=1:intervals(i,3)-intervals(i,2)+1 %for each frame of spot
       if j+intervals(i,2)-1>=min_frame %not less than min frame
           if j+intervals(i,2)-1<=max_frame %not greater than max frame
               frame_counter=frame_counter+1;
               graph(spot_counter,frame_counter)=intervals(i,1);
               %[spot_counter frame_counter  j intervals(i,1) j+intervals(i,2)-1]
           end
       end
   end
end
%now to replace all -2, 0, +2 with fours, 
graph(graph==-2)=4;
graph(graph==0)=4;
graph(graph==2)=4;
%now to replace all -3, +1, +3 with eights
graph(graph==-3)=16;
graph(graph==1)=16;
graph(graph==3)=16;
%Fixes graph to reflect incorrect requests
frame_diff=min(intervals(:,2))-min_frame;
if frame_diff>0 %requested min frame is lower than actual
    graph=[zeros(spot_number,frame_diff)-4 graph];
    graph(:,end-frame_diff+1:end)=[];
end
%if silent ==1 don;t graph anything, just return the matrix
if silent==1
   return; 
end
%get matrix of time info
header=load(header_path,'-mat');
time2frames=header.vid.ttb(min_frame:max_frame);
%now to graph the results
func_graph_intervals_time_graph_ega(graph,time2frames,-4,4,100,150,16);%100 and 150 shouldnt occur




